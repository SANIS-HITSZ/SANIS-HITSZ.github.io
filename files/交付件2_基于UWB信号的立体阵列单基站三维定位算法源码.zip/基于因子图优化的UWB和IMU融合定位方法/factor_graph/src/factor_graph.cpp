#include "ros/ros.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <sstream>
#include <cctype>
#include <cmath>
#include <complex>
#include <regex>
#include <stdexcept>
#include <queue>
#include <unordered_set>
#include <eigen3/Eigen/Dense>
#include <gtsam/nonlinear/Values.h>
#include <gtsam/inference/Symbol.h>
#include <gtsam/geometry/Point3.h>
#include <gtsam/geometry/Pose3.h>
#include <gtsam/sam/RangeFactor.h>
#include <gtsam/sam/BearingFactor.h>
#include <gtsam/navigation/CombinedImuFactor.h>
#include <gtsam/navigation/ImuFactor.h>
#include <gtsam/navigation/ImuBias.h>
#include <gtsam/slam/BetweenFactor.h>
#include <gtsam/slam/dataset.h>
#include <gtsam/nonlinear/NonlinearFactorGraph.h>
#include <gtsam/nonlinear/LevenbergMarquardtOptimizer.h>
#include <gtsam/nonlinear/ISAM2.h>
#include <gtsam/nonlinear/DoglegOptimizer.h>
#include <gtsam/nonlinear/GaussNewtonOptimizer.h>
#include <gtsam/inference/Key.h>
#include <matplotlibcpp.h>
#include </home/aowu/owr_imu_3d/devel/include/uwb_demo/uwb_msg.h>
#include <sensor_msgs/Imu.h>

#define pi M_PI

using namespace gtsam;
using namespace std;
namespace plt = matplotlibcpp;

int datalen;

int calibration_len = 100;
Matrix timestamp(calibration_len, 3);
Vector timestamp_calibrated(calibration_len);

// 时钟矫正参数定义
double k1, k2, k3;

class TOAFactor : public NoiseModelFactorN<Pose3, Point3, Vector1> {
private:
    double txtimestamp_, rxtimestamp_;
    double c_, f_;

public:
    TOAFactor(Key node_key, Key anchor_key, Key clock_key,
                double txtimestamp, double rxtimestamp, double c, double f,
                const SharedNoiseModel& model)
        : NoiseModelFactorN<Pose3, Point3, Vector1>(model, {node_key, anchor_key, clock_key}),
            txtimestamp_(txtimestamp), rxtimestamp_(rxtimestamp),
            c_(c), f_(f) {}

    Vector evaluateError(const Pose3& node_pose, const Point3& anchor_pose, const Vector1& clock_params,
                        OptionalMatrixType H1,
                        OptionalMatrixType H2,
                        OptionalMatrixType H3) const override {
        // 1. 计算矫正后的时间和测量距离
        double corrected_time = k1 * rxtimestamp_ * rxtimestamp_ + k2 * rxtimestamp_ + clock_params[0];
        // std::cout << k1 << "," << k2 << "," << k3 << "," << corrected_time << std::endl;

        double delta_t, measured_distance;
        
        delta_t = corrected_time - txtimestamp_;
        measured_distance = delta_t * c_;

        // 2. 计算预测距离 ||node_pos - anchor_pos||
        Point3 node_position = node_pose.translation();
        Vector3 relative_position = node_position - anchor_pose;
        double predicted_distance = relative_position.norm();
        
        // 3. 误差 = 测量距离 - 预测距离
        Vector1 error(measured_distance - predicted_distance);
        // std::cout << "measured_distance: " << measured_distance << ", predicted_distance: " << predicted_distance << ", error:" << error << std::endl;

        // 4. 计算雅可比矩阵（如果需要）
        if (H1 || H2 || H3) {
            // 预处理：计算距离导数公共部分
            Matrix13 distance_derivative;
            if (predicted_distance > 1e-8) {
                distance_derivative = relative_position.transpose() / predicted_distance;
            } else {
                distance_derivative.setZero();
            }

            // 4.1 对节点位姿的雅可比
            if (H1) {
                *H1 = Matrix::Zero(1, 6);
                // 仅对平移部分有导数 (1x3)
                H1->block<1, 3>(0, 3) = distance_derivative;
                // 旋转部分导数为0 (因为距离与旋转无关)
            }

            // 4.2 对基站位置的雅可比
            if (H2) {
                *H2 = Matrix::Zero(1, 3);
                *H2 = -distance_derivative;
            }

            // 4.3 对时钟参数的雅可比
            if (H3) {
                *H3 = Matrix::Zero(1, 1);
                double time_derivative = c_ / f_;  // 公共项
                (*H3)(0, 0) = c_;  // 对clock_drift的导数
                // (*H3)(0, 1) = rxtimestamp_ * time_derivative;  // 对clock_drift的导数
                // (*H3)(0, 2) = time_derivative;                 // 对clock_offset的导数
            }
        }

        return error;
    }
};

class DirectionVectorFactor : public NoiseModelFactor2<Pose3, Point3> {
private:
    double azi_, ezi_;  // 测量到的方位角（azimuth）和俯仰角（elevation）

public:
    DirectionVectorFactor(Key node_key, Key anchor_key,
                            double azi, double ezi,
                            const SharedNoiseModel& model)
        : NoiseModelFactor2<Pose3, Point3>(model, {node_key, anchor_key}),
            azi_(azi), ezi_(ezi) {}

    Vector evaluateError(const Pose3& node_pose, const Point3& anchor_pose,
                        OptionalMatrixType H1,
                        OptionalMatrixType H2) const override {
        // 获取节点和基站的位置
        Point3 anchor_position = anchor_pose;
        Point3 node_position = node_pose.translation();
        
        // 计算相对位置向量
        Vector3 relative_position = node_position - anchor_position;
        Unit3 predicted_direction(relative_position);  // 预测方向（单位化）

        // 将测量角度转换到全局坐标系
        double new_azi = azi_ + node_pose.rotation().yaw();
        double new_ezi = -ezi_ + node_pose.rotation().pitch();
        // std::cout << new_azi / pi *180 << new_ezi / pi * 180 << std::endl;
        
        // 根据角度构建测量方向向量
        Vector3 measured_angle;
        measured_angle[0] = cos(new_ezi) * cos(new_azi);
        measured_angle[1] = cos(new_ezi) * sin(new_azi);
        measured_angle[2] = sin(new_ezi);
        Unit3 measured_direction(measured_angle);

        // 误差 = 测量方向与预测方向之间的差值
        Vector3 error = measured_direction.unitVector() - predicted_direction.unitVector();
        // std::cout << measured_direction.unitVector().transpose() << "," << predicted_direction.unitVector().transpose() << std::endl;

        if (H1) {
            (*H1) = Matrix::Zero(3, 6);

            // 1. 对节点位置的雅可比 (平移部分)
            // Matrix33 d_dir_d_node_pos = -predicted_direction.basis() * predicted_direction.basis().transpose() / relative_position.norm();
            Matrix33 d_dir_d_node_pos = Matrix::Zero(3,3);
            d_dir_d_node_pos(0, 0) = - (relative_position(1) * relative_position(1) + relative_position(2) * relative_position(2)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            d_dir_d_node_pos(1, 1) = - (relative_position(0) * relative_position(0) + relative_position(2) * relative_position(2)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            d_dir_d_node_pos(2, 2) = - (relative_position(0) * relative_position(0) + relative_position(1) * relative_position(1)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            (*H1).block<3, 3>(0, 3) = d_dir_d_node_pos;

            // 2. 对节点旋转的雅可比 (旋转部分)
            Matrix33 d_meas_d_rpy = Matrix::Zero(3, 3);
            double sa = sin(new_azi), ca = cos(new_azi);
            double se = sin(new_ezi), ce = cos(new_ezi);
            
            // 测量方向对yaw角(z轴旋转)的导数
            d_meas_d_rpy(0, 2) = ce * ca;   // dx/dyaw
            d_meas_d_rpy(1, 2) = -ce * sa;  // dy/dyaw
            d_meas_d_rpy(2, 2) = 0;         // dz/dyaw
            
            // 测量方向对pitch角(y轴旋转)的导数
            d_meas_d_rpy(0, 1) = -se * sa;  // dx/dpitch
            d_meas_d_rpy(1, 1) = -se * ca;  // dy/dpitch
            d_meas_d_rpy(2, 1) = ce;      // dz/dpitch
            
            // 注意：这里roll角(x轴旋转)不影响测量方向，所以导数为0
            
            // 将RPY导数转换为旋转矩阵的导数
            Matrix33 d_rpy_d_rot = node_pose.rotation().matrix().transpose();
            (*H1).block<3, 3>(0, 0) = d_meas_d_rpy * d_rpy_d_rot;
        }

        if (H2) {
            // 对基站位置的雅可比
            (*H2) = Matrix::Zero(3, 3);  // Point3只有3维位置
            
            // Matrix33 d_dir_d_anchor_pos = predicted_direction.basis() * predicted_direction.basis().transpose() / relative_position.norm();
            Matrix33 d_dir_d_anchor_pos = Matrix::Zero(3,3);
            d_dir_d_anchor_pos(0, 0) = (relative_position(1) * relative_position(1) + relative_position(2) * relative_position(2)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            d_dir_d_anchor_pos(1, 1) = (relative_position(0) * relative_position(0) + relative_position(2) * relative_position(2)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            d_dir_d_anchor_pos(2, 2) = (relative_position(0) * relative_position(0) + relative_position(1) * relative_position(1)) / (relative_position.norm() * relative_position.norm() * relative_position.norm());
            (*H2).block<3, 3>(0, 0) = d_dir_d_anchor_pos;
        }
        
        return error;
    }
};

// 定义符号简写
using symbol_shorthand::X; // Pose3 (x,y,z,r,p,y)
using symbol_shorthand::V; // Vel   (xdot,ydot,zdot)
using symbol_shorthand::B; // Bias  (ax,ay,az,gx,gy,gz)

size_t imu_index = -1;
size_t uwb_index = -1;

double uwb_previous, uwb_current, uwb_dt;
double x_previous, y_previous, z_previous, x_current, y_current, z_current, dx, dy, dz, vx, vy, vz;

// 输出结果
std::string datafile = "trajectory.csv";
// std::ofstream outfile1("output_uwb.csv");
std::ofstream outfile("output.csv");
std::vector<double> x_initial, y_initial, z_initial, roll_initial, pitch_initial, yaw_initial, roll, pitch, yaw;
std::vector<double> x_optimized, y_optimized, z_optimized, roll_optimized, pitch_optimized, yaw_optimized;

ISAM2Params params;
ISAM2GaussNewtonParams gn_params;
ISAM2 isam(params);

Values initial_front;

// 先验信息
double x_anchor = 0.0;
double y_anchor = 0.0;
double z_anchor = 0.0;

// UWB参数
double fclock = 124.8e6 * 4 * 128;
double c = 3e8;

double old_azi = 0.0;

// UWB基站位置
gtsam::Key X_anchor = gtsam::Symbol('A', 0);

auto anchor_noise = noiseModel::Diagonal::Sigmas(Vector3(0.01, 0.01, 0.01));

// 时钟误差状态
std::vector<gtsam::Key> clock_keys;

// 添加先验因子
noiseModel::Diagonal::shared_ptr pose_noise_model0 =
    noiseModel::Diagonal::Sigmas((Vector(6) << 0.01, 0.01, 0.01, 0.01, 0.01, 0.01).finished());
noiseModel::Diagonal::shared_ptr velocity_noise_model0 =
    noiseModel::Diagonal::Sigmas(Vector3(0.01, 0.01, 0.01));
noiseModel::Diagonal::shared_ptr bias_noise_model0 =
    noiseModel::Diagonal::Sigmas(Vector6::Constant(0.01));
noiseModel::Diagonal::shared_ptr clock_noise_model0 =
    noiseModel::Diagonal::Sigmas(Vector1(0.01));

noiseModel::Diagonal::shared_ptr pose_noise_model =
    noiseModel::Diagonal::Sigmas((Vector(6) << 1e-4, 1e-4, 1e-4, 0.5, 0.5, 0.5).finished());
noiseModel::Diagonal::shared_ptr velocity_noise_model =
    noiseModel::Diagonal::Sigmas(Vector3(0.1, 0.1, 0.1));
noiseModel::Diagonal::shared_ptr bias_noise_model =
    noiseModel::Diagonal::Sigmas(Vector6::Constant(0.1));

// 测距噪声参数
auto range_noise = noiseModel::Isotropic::Sigma(1, 0.01);
auto range_noise_timestamp = noiseModel::Isotropic::Sigma(1, 1.0);
auto toa_clock_noise = noiseModel::Isotropic::Sigma(1, 1.0);

// 测角噪声参数
auto bearing_noise = noiseModel::Diagonal::Sigmas(Vector2(1.0, 1.0));

// 单位向量噪声参数
auto direction_noise = noiseModel::Diagonal::Sigmas(Vector3(0.1, 0.1, 0.1));

// 速度噪声参数
auto velocity_noise = noiseModel::Diagonal::Sigmas(Vector3(0.1, 0.1, 0.1));

// IMU偏置噪声参数
auto bias_noise = noiseModel::Diagonal::Sigmas(Vector6(1.0, 1.0, 1.0, 1.0, 1.0, 1.0));

// IMU噪声参数
const double accel_noise_sigma = 9.0728880243675578e-03;  // 加速度计噪声标准差
const double gyro_noise_sigma = 1e-03;  // 陀螺仪噪声标准差
const double accel_bias_rw_sigma = 3.5869397887245118e-04;  // 加速度计偏置随机游走标准差
const double gyro_bias_rw_sigma = 1e-04;  // 陀螺仪偏置随机游走标准差

auto clock_noise = noiseModel::Diagonal::Sigmas(Vector1(1e-6));

// 创建IMU预积分参数
auto imu_params = PreintegratedCombinedMeasurements::Params::MakeSharedU(9.81);

imuBias::ConstantBias prior_bias(
    Vector3(0.488086, -0.0239258, 9.77129-9.81),
    Vector3(0.0, 0.0, 0.0)
); // 初始偏置

// 创建IMU预积分器
PreintegratedCombinedMeasurements imu_preintegrated(imu_params, prior_bias);
PreintegratedCombinedMeasurements imu_integrated(imu_params, prior_bias);

double previous_time, current_time, delta_t;

int64_t prior_clock_bias;
int64_t txtimestamp0, rxtimestamp0, drxtimestamp;

// 创建因子图/初始估计/优化结果
NonlinearFactorGraph graph;
Values initial_estimates, results;

// 分割CSV行（按逗号分割）
std::vector<std::string> splitcsvline(const std::string &line) {
    std::vector<std::string> tokens;
    std::string token;
    bool inQuotes = false;
    for (char ch : line) {
        if (ch == '"') {
            inQuotes = !inQuotes;
        } else if (ch == ',' && !inQuotes) {
            tokens.push_back(token);
            token.clear();
        } else if (ch != '(' || ch != ')') {
            token += ch;
        }
    }
    tokens.push_back(token); // 添加最后一个字段
    return tokens;
}

// 解析整数复数字符串
complex<int> parseComplexInt(const string& str) {
    regex standard_form(R"(\(([+-]?\d+)([+-]\d+)j\))"); // (a+bj) 或 (a-bj)
    regex real_only_form(R"(([+-]?\d+))");              // a 或 -a
    regex imag_only_form(R"(([+-]?\d+)j)");             // bj 或 -bj
    smatch match;

    if (regex_match(str, match, standard_form)) {
        return complex<int>(stoi(match[1]), stoi(match[2]));
    }
    else if (regex_match(str, match, real_only_form)) {
        return complex<int>(stoi(match[1]), 0);
    }
    else if (regex_match(str, match, imag_only_form)) {
        return complex<int>(0, stoi(match[1]));
    }
    else {
        return complex<int>(0, 0);
    }
}

// 打印ISAM内部节点
void isam_factor_print(ISAM2 isam) {
    gtsam::VariableIndex variable_index = isam.getVariableIndex();
    std::cout << "Node in variable index: " ;
    for (const auto& var : variable_index) {
        gtsam::Key key = var.first;
        std::cout << gtsam::DefaultKeyFormatter(key) << " ";
    }
    std::cout << std::endl;
}

// 打印队列内部节点
void queue_factor_print(std::queue<gtsam::Key> temp) {
    std::cout << "当前activekeysy中的节点: ";
    while (!temp.empty()) {
        gtsam::Key key = temp.front();
        temp.pop();
        std::cout << gtsam::DefaultKeyFormatter(key) << " ";
    }
    std::cout << std::endl;
}

// 打印graph内部变量
void graph_variables_print(const gtsam::NonlinearFactorGraph& graph) {
    std::unordered_set<gtsam::Key> variables;

    for (const auto& factor : graph) {
        if (factor) {
            for (gtsam::Key key : factor->keys()) {
                variables.insert(key);
            }
        }
    }

    std::cout << "Variables in the graph: ";
    for (gtsam::Key key : variables) {
        std::cout << gtsam::DefaultKeyFormatter(key) << " ";
    }
    std::cout << std::endl;
}

// 打印initial_estimates内部变量
void initial_variables_print(const gtsam::Values& initial_estimates) {
    std::cout << "Initial Estimates variables: ";
    for (const auto& key_value : initial_estimates) {
        std::cout << DefaultKeyFormatter(key_value.key) << " ";
    }
    std::cout << std::endl;
}

void uwb_process(const std::vector<std::string> stringrow) {
    uwb_index++;
    double uwb_time = std::stod(stringrow[0]);
    int64_t txtimestamp = int64_t(std::stod(stringrow[1]));
    int64_t rxtimestamp = int64_t(std::stod(stringrow[2]));
    double uwb_distance = std::stod(stringrow[3]);
    double uwb_distance_timestamp;
    double uwb_azi = std::stod(stringrow[4]);
    double uwb_ezi = std::stod(stringrow[5]);

    if (uwb_azi > 180) {
        uwb_azi = uwb_azi - 360;
    }

    if (uwb_ezi > 180) {
        uwb_ezi = uwb_ezi - 360;
    }

    uwb_azi = -uwb_azi / 180.0 * pi;
    uwb_ezi = uwb_ezi / 180.0 * pi;

    if (uwb_index == 0) {
        // 添加基站位置
        graph.addPrior(X_anchor, gtsam::Point3(x_anchor, y_anchor, z_anchor), anchor_noise);
        initial_estimates.insert(X_anchor, gtsam::Point3(x_anchor, y_anchor, z_anchor));

        uwb_current = uwb_time;

        Rot3 init_rotation = Rot3::Rz(0.0);  // yaw : 0度

        // 将测量角度转换到全局坐标系
        double new_azi = uwb_azi + init_rotation.yaw();
        double new_ezi = -uwb_ezi + init_rotation.pitch();
        x_current = uwb_distance * cos(new_ezi) * cos(new_azi);
        y_current = uwb_distance * cos(new_ezi) * sin(new_azi);
        z_current = uwb_distance * sin(new_ezi);

        Point3 init_translation(x_current, y_current, z_current);
        Pose3 init_pose(init_rotation, init_translation);
        Vector3 init_velocity(0.0, 0.0, 0.0);
        NavState init_state(init_pose, init_velocity);

        prior_clock_bias = rxtimestamp - txtimestamp - int64_t(uwb_distance / c * fclock);

        rxtimestamp = rxtimestamp - prior_clock_bias;

        txtimestamp0 = txtimestamp;
        rxtimestamp0 = rxtimestamp;

        timestamp(uwb_index, 0) = rxtimestamp * rxtimestamp / fclock;
        timestamp(uwb_index, 1) = rxtimestamp / fclock;
        timestamp(uwb_index, 2) = 1;
        timestamp_calibrated(uwb_index) = (txtimestamp + int64_t(uwb_distance / c * fclock)) / fclock; 
        
        Vector1 prior_clock;
        prior_clock << 0.0;

        // 添加先验因子到图中
        graph.addPrior(X(uwb_index), init_state.pose(), pose_noise_model);
        graph.addPrior(V(uwb_index), init_state.v(), velocity_noise_model);
        graph.addPrior(B(uwb_index), prior_bias, bias_noise_model);

        // 将初始估计添加到值中
        initial_estimates.insert(X(uwb_index), init_state.pose());
        initial_estimates.insert(V(uwb_index), init_state.v());
        initial_estimates.insert(B(uwb_index), prior_bias);

        initial_front = initial_estimates;

        // 添加测距约束
        gtsam::RangeFactor<gtsam::Pose3,gtsam::Point3> uwb_range_factor(
            X(uwb_index),
            X_anchor,
            uwb_distance,
            range_noise);
        graph.add(uwb_range_factor);
        
        if (abs(new_azi) <= 50.0 / 180 * pi & abs(new_ezi) <= 50.0 / 180 * pi) {
            // 添加测角约束
            Point3 direction(-x_current, -y_current, -z_current);
            Unit3 bearing = Unit3::FromPoint3(direction);
            BearingFactor<Pose3,Point3,Unit3> uwb_bearing_factor(
                X(uwb_index),
                X_anchor,
                bearing,
                bearing_noise);
            graph.add(uwb_bearing_factor);
        }

        auto uwb_direction_factor = std::make_shared<DirectionVectorFactor>(
            X(uwb_index),
            X_anchor,
            uwb_azi,
            uwb_ezi,
            direction_noise
        );
        graph.add(uwb_direction_factor);

        // 增量更新
        isam.update(graph, initial_estimates);
        isam.update();

        // 优化问题求解
        results = isam.calculateEstimate();

        // 输出初始结果
        Pose3 pose_initial = initial_estimates.at<Pose3>(X(uwb_index));
        Vector3 velocity_initial = initial_estimates.at<Vector3>(V(uwb_index));
        imuBias::ConstantBias bias_initial = initial_estimates.at<imuBias::ConstantBias>(B(uwb_index));
        
        x_initial.push_back(pose_initial.translation().x());
        y_initial.push_back(pose_initial.translation().y());
        z_initial.push_back(pose_initial.translation().z());

        graph.resize(0);
        initial_estimates.clear();
    }
    else if (uwb_index > 0) {
        std::cout << uwb_index << std::endl;

        uwb_previous = uwb_current;
        uwb_current = uwb_time;
        uwb_dt = uwb_current - uwb_previous;

        if (delta_t > 0) {
            uwb_dt = delta_t;
        }
        else {
            uwb_dt = 0.01;
        }
        
        // 添加初始估计 (使用IMU预积分结果预测)
        NavState prev_state(results.at<Pose3>(X(uwb_index-1)),results.at<Vector3>(V(uwb_index-1)));
        imuBias::ConstantBias prev_bias = results.at<imuBias::ConstantBias>(B(uwb_index-1));
        NavState prop_state = imu_preintegrated.predict(prev_state, prev_bias);

        x_previous = x_current;
        y_previous = y_current;
        z_previous = z_current;

        // 将测量角度转换到全局坐标系
        double new_azi = uwb_azi + prop_state.rotation().yaw();
        double new_ezi = -uwb_ezi + prop_state.rotation().pitch();
        x_current = uwb_distance * cos(new_ezi) * cos(new_azi);
        y_current = uwb_distance * cos(new_ezi) * sin(new_azi);
        z_current = uwb_distance * sin(new_ezi);

        dx = x_current - x_previous;
        dy = y_current - y_previous;
        dz = z_current - z_previous;

        vx = dx / uwb_dt;
        vy = dy / uwb_dt;
        vz = dz / uwb_dt;

        Pose3 prop_pose = prop_state.pose();
        Rot3 prop_rotation = prop_pose.rotation();
        Point3 uwb_translation(x_current, y_current, z_current);
        Pose3 uwb_pose(prop_rotation, uwb_translation);

        if (abs(new_azi - old_azi) > 5.0 / 180 *pi) {
            std::cout << old_azi << "," << new_azi << std::endl;
            pose_noise_model = noiseModel::Diagonal::Sigmas((Vector(6) << 1e-4, 1e-4, 1e-4, 0.01, 0.01, 0.01).finished());
        }
        else {
            pose_noise_model = noiseModel::Diagonal::Sigmas((Vector(6) << 0.01, 0.01, 0.01, 0.4, 0.4, 0.4).finished());
        }
        
        // 添加先验因子到图中
        graph.addPrior(X(uwb_index), prop_pose, pose_noise_model);
        graph.addPrior(V(uwb_index), prop_state.velocity(), velocity_noise_model);
        graph.addPrior(B(uwb_index), prev_bias, bias_noise_model);

        // 将初始估计添加到值中
        initial_estimates.insert(X(uwb_index), prop_pose);
        initial_estimates.insert(V(uwb_index), prop_state.velocity());
        initial_estimates.insert(B(uwb_index), prev_bias);

        initial_front = initial_estimates;

        // 添加测距约束
        RangeFactor<Pose3,Point3> uwb_range_factor(
            X(uwb_index),
            X_anchor,
            uwb_distance,
            range_noise);
        graph.add(uwb_range_factor);

        if (abs(new_azi - old_azi) < 5.0 / 180 * pi) {
            // 添加测角约束
            Point3 direction(-x_current, -y_current, -z_current);
            Unit3 bearing = Unit3::FromPoint3(direction);
            BearingFactor<Pose3,Point3,Unit3> uwb_bearing_factor(
                X(uwb_index),
                X_anchor,
                bearing,
                bearing_noise);
            graph.add(uwb_bearing_factor);

            auto uwb_direction_factor = std::make_shared<DirectionVectorFactor>(
                X(uwb_index),
                X_anchor,
                uwb_azi,
                uwb_ezi,
                direction_noise
            );
            graph.add(uwb_direction_factor);
        }
        
        if (imu_preintegrated.deltaTij() > 0) {
            // 创建IMU因子
            CombinedImuFactor imu_factor(
                X(uwb_index-1), V(uwb_index-1), 
                X(uwb_index), V(uwb_index), 
                B(uwb_index-1), B(uwb_index), 
                imu_preintegrated);
            graph.add(imu_factor);
        }else {
            // 添加速度约束
            graph.add(BetweenFactor<Vector3>(
                V(uwb_index-1), V(uwb_index), 
                Vector3::Zero(),
                velocity_noise
            ));

            // 添加IMU偏置约束
            graph.add(BetweenFactor<imuBias::ConstantBias>(
                B(uwb_index-1), B(uwb_index), 
                imuBias::ConstantBias(),
                bias_noise
            ));
        }

        // 增量更新
        isam.update(graph, initial_estimates);
        isam.update();

        // 优化问题求解
        results = isam.calculateEstimate();

        // 输出初始结果
        Pose3 pose_initial = initial_estimates.at<Pose3>(X(uwb_index));
        Vector3 velocity_initial = initial_estimates.at<Vector3>(V(uwb_index));
        imuBias::ConstantBias bias_initial = initial_estimates.at<imuBias::ConstantBias>(B(uwb_index));
        
        if (uwb_index > 450 & uwb_index < 1450 + 1) {
            x_initial.push_back(uwb_pose.translation().x());
            y_initial.push_back(uwb_pose.translation().y());
            z_initial.push_back(uwb_pose.translation().z());
            roll_initial.push_back(uwb_pose.rotation().roll() / pi * 180);
            pitch_initial.push_back(uwb_pose.rotation().pitch() / pi * 180);
            yaw_initial.push_back(uwb_pose.rotation().yaw() / pi * 180);

            roll.push_back(imu_integrated.deltaXij().rotation().roll() / pi * 180);
            pitch.push_back(imu_integrated.deltaXij().rotation().pitch() / pi * 180);
            yaw.push_back(imu_integrated.deltaXij().rotation().yaw() / pi * 180);
        }

        if(uwb_index == 1676)
        {
            for (size_t i = 450 + 1; i < 1450 + 1; i++)
            {
                // 输出优化结果
                Pose3 pose_optimized = results.at<Pose3>(X(i));
                Vector3 velocity_optimized = results.at<Vector3>(V(i));
                imuBias::ConstantBias bias_optimized = results.at<imuBias::ConstantBias>(B(i));
                outfile << pose_optimized.translation().transpose();
                outfile << pose_optimized.rotation().rpy().transpose();
                outfile << bias_optimized.accelerometer().transpose();
                outfile << bias_optimized.gyroscope().transpose() << std::endl;

                x_optimized.push_back(pose_optimized.translation().x());
                y_optimized.push_back(pose_optimized.translation().y());
                z_optimized.push_back(pose_optimized.translation().z());
                roll_optimized.push_back(pose_optimized.rotation().roll() / pi * 180);
                pitch_optimized.push_back(pose_optimized.rotation().pitch() / pi * 180);
                yaw_optimized.push_back(pose_optimized.rotation().yaw() / pi * 180);
                std::cout << yaw[i - (450 + 1)] << "," << yaw_optimized[i - (450 + 1)] << std::endl;
            }

            // 绘制位置散点图
            plt::figure(1);
            plt::scatter(x_initial, y_initial, 10.0, {{"color", "b"}, {"label", "Initial Position"}});
            plt::scatter(x_optimized, y_optimized, 10.0, {{"color", "r"}, {"label", "Optimized Position"}});
            plt::xlim(0, 8);
            plt::ylim(-4, 4);
            plt::title("Trajectory");
            plt::xlabel("X/m");
            plt::ylabel("Y/m");
            plt::grid(true);
            plt::legend();
            plt::save("trajectory_1_xoy.png");
            plt::save("trajectory_1_xoy.pdf");
            plt::show();

            // 绘制位置散点图
            plt::figure(2);
            plt::scatter(x_initial, z_initial, 10.0, {{"color", "b"}, {"label", "Initial Position"}});
            plt::scatter(x_optimized, z_optimized, 10.0, {{"color", "r"}, {"label", "Optimized Position"}});
            plt::xlim(0, 8);
            plt::ylim(-4, 4);
            plt::title("Trajectory");
            plt::xlabel("X/m");
            plt::ylabel("Z/m");
            plt::grid(true);
            plt::legend();
            plt::save("trajectory_1_xoz.png");
            plt::save("trajectory_1_xoz.pdf");
            plt::show();

            // 绘制姿态散点图
            std::vector<int64_t> sample(roll_optimized.size());
            for (size_t i = 0; i < roll_optimized.size(); i++) {
                sample[i] = i;
            }

            plt::figure(3);
            plt::scatter(sample, roll, 10.0, {{"color", "b"}, {"label", "Initial Roll"}});
            plt::scatter(sample, roll_optimized, 10.0, {{"color", "r"}, {"label", "Optimized Roll"}});
            plt::xlim(0, 1000);
            plt::ylim(-5, 5);
            plt::title("Pose-Roll");
            plt::xlabel("Sample");
            plt::ylabel("Roll/°");
            plt::grid(true);
            plt::legend();
            plt::save("pose_1_roll.png");
            plt::save("pose_1_roll.pdf");
            plt::show();

            plt::figure(4);
            plt::scatter(sample, pitch, 10.0, {{"color", "b"}, {"label", "Initial Pitch"}});
            plt::scatter(sample, pitch_optimized, 10.0, {{"color", "r"}, {"label", "Optimized Pitch"}});
            plt::xlim(0, 1000);
            plt::ylim(-5, 5);
            plt::title("Pose-Pitch");
            plt::xlabel("Sample");
            plt::ylabel("Pitch/°");
            plt::grid(true);
            plt::legend();
            plt::save("pose_1_pitch.png");
            plt::save("pose_1_pitch.pdf");
            plt::show();

            plt::figure(5);
            plt::scatter(sample, yaw, 10.0, {{"color", "b"}, {"label", "Initial Yaw"}});
            plt::scatter(sample, yaw_optimized, 10.0, {{"color", "r"}, {"label", "Optimized Yaw"}});
            plt::xlim(0, 1000);
            plt::ylim(-5, 5);
            plt::title("Pose-Yaw");
            plt::xlabel("Sample");
            plt::ylabel("Yaw/°");
            plt::grid(true);
            plt::legend();
            plt::save("pose_1_yaw.png");
            plt::save("pose_1_yaw.pdf");
            plt::show();
        }

        // old_azi = new_azi;
        old_azi = atan(results.at<Pose3>(X(uwb_index)).translation().y() / results.at<Pose3>(X(uwb_index)).translation().x());
        
        graph.resize(0);
        initial_estimates.clear();
    }
    
    // 重置预积分器
    imu_preintegrated.resetIntegration();
    delta_t = 0.0;
}

void imu_process(const std::vector<std::string> stringrow) {
    imu_index++;
    current_time = std::stod(stringrow[0]);
            
    if (imu_index > 0) {
        current_time = std::stod(stringrow[0]);
        // delta_t = current_time - previous_time;
        delta_t = delta_t + 0.005;

        // IMU测量数据(从传感器读取)
        std::vector<double> acc_measurements; // 加速度测量值
        std::vector<double> gyro_measurements; // 角速度测量值
        acc_measurements.resize(3);
        gyro_measurements.resize(3);

        acc_measurements[0] = std::stod(stringrow[1]);
        acc_measurements[1] = std::stod(stringrow[2]);
        acc_measurements[2] = std::stod(stringrow[3]);
        gyro_measurements[0] = std::stod(stringrow[4]);
        gyro_measurements[1] = std::stod(stringrow[5]);
        gyro_measurements[2] = std::stod(stringrow[6]);
        Eigen::Vector3d measured_acc = Eigen::Map<Vector3>(acc_measurements.data());
        Eigen::Vector3d measured_gyro = Eigen::Map<Vector3>(gyro_measurements.data());
        
        // 预积分当前测量值
        imu_preintegrated.integrateMeasurement(measured_acc, measured_gyro, 0.005);
        imu_integrated.integrateMeasurement(measured_acc, measured_gyro, 0.005);
    }

    previous_time = current_time;
}

int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");
    ros::init(argc,argv,"implement");
    ros::NodeHandle nh;

    // 固定打印格式:打印输出20位小数
    std::cout << std::fixed << std::setprecision(20);

    gn_params.setWildfireThreshold(1e-5);
    params.optimizationParams = gn_params;
    params.enableRelinearization = true;
    params.relinearizeThreshold = 1e-5;
    params.relinearizeSkip = 1;
    params.enablePartialRelinearizationCheck = false;

    // 设置噪声协方差矩阵
    imu_params->accelerometerCovariance = 
        Matrix3::Identity(3,3) * pow(accel_noise_sigma, 2);
    imu_params->gyroscopeCovariance = 
        Matrix3::Identity(3,3) * pow(gyro_noise_sigma, 2);
    imu_params->integrationCovariance = 
        Matrix3::Identity(3,3) * 0.1; // 积分误差

    // 设置偏置随机游走噪声
    imu_params->biasAccCovariance = 
        Matrix3::Identity(3,3) * pow(accel_bias_rw_sigma, 2);
    imu_params->biasOmegaCovariance = 
        Matrix3::Identity(3,3) * pow(gyro_bias_rw_sigma, 2);
    imu_params->biasAccOmegaInt = 
        Matrix::Identity(6,6) * 0.1; // 初始偏置协方差
    
    std::ifstream infile(datafile);
    if (!infile.is_open())
    {
        std::cerr << "无法打开输入文件: " << datafile << std::endl;
        return 1;
    }
    std::string line;
    std::vector<std::string> stringrow;
    std:vector<std::vector<std::string>> stringrows;
    while (std::getline(infile,line))
    {
        stringrow = splitcsvline(line);
        stringrows.push_back(stringrow);
    }
    infile.close();
    std::cout << "数据量:" << stringrows.size() << std::endl;

    datalen = stringrows.size();

    for (size_t i = 0; i < datalen; i++)
    {
        if (stringrows[i].size() == 7) {
            imu_process(stringrows[i]);
        }
        else if (stringrows[i].size() == 6) {
            uwb_process(stringrows[i]);
        }
    }
}

