

clc; clear; close all;

rng('default');   % 恢复到 startup configuration
rng(42);           % 固定随机数种子

% =====================
% 1. 数据模拟
% =====================
N = 500;
true_distance = linspace(2, 30, N)'; % 真实距离 2~30m

% 随机LOS/NLOS状态（0=LOS，1=NLOS）
labels = rand(N,1) > 0.6; % 约40%是NLOS

% 模拟测距误差
los_error = normrnd(0, 0.15, N, 1);     % LOS误差 ~ ±15cm
nlos_error = normrnd(1.2, 0.4, N, 1);   % NLOS误差 ~ 1.2m ± 0.4m

measured_distance = true_distance + (~labels).*los_error + labels.*nlos_error;

% =====================
% 2. 特征提取（假设来自CIR）
% =====================
delay_spread = (~labels).*normrnd(3, 1, N, 1) + ...
               (labels).*normrnd(10, 2, N, 1); % ns
energy_ratio = (~labels).*normrnd(0.9, 0.05, N, 1) + ...
               (labels).*normrnd(0.6, 0.1, N, 1);

% 特征矩阵
X = [delay_spread, energy_ratio, measured_distance];
y = labels; % 0=LOS, 1=NLOS

% =====================
% 3. 划分训练/测试集
% =====================
cv = cvpartition(N, 'HoldOut', 0.3);
idxTrain = training(cv);
idxTest = test(cv);

X_train = X(idxTrain,:);
X_test  = X(idxTest,:);
y_train = y(idxTrain);
y_test  = y(idxTest);
d_train = measured_distance(idxTrain);
d_test  = measured_distance(idxTest);
true_train = true_distance(idxTrain);
true_test  = true_distance(idxTest);

% =====================
% 4. LOS/NLOS分类（SVM）
% =====================
SVMModel = fitcsvm(X_train, y_train, 'KernelFunction', 'rbf', ...
                   'BoxConstraint', 10, 'KernelScale', 'auto');
y_pred_cls = predict(SVMModel, X_test);

acc = sum(y_pred_cls == y_test) / length(y_test);
fprintf("LOS/NLOS 分类准确率: %.2f%%\n", acc*100);

% =====================
% 5. NLOS误差补偿（SVR）
% =====================
nlos_idx_train = (y_pred_cls == 1);
nlos_features_train = X_train(nlos_idx_train,:);
nlos_error_train = d_train(nlos_idx_train) - true_train(nlos_idx_train);

SVRModel = fitrsvm(nlos_features_train, nlos_error_train, ...
                   'KernelFunction', 'rbf', ...
                   'BoxConstraint', 10, ...
                   'KernelScale', 'auto');

% 测试集误差补偿
corrected_distance = zeros(size(d_test));
for i = 1:length(d_test)
    if y_pred_cls(i) == 1 % 判为NLOS
        err_pred = predict(SVRModel, X_test(i,:));
        corrected_distance(i) = d_test(i) - err_pred;
    else
        corrected_distance(i) = d_test(i); % LOS不补偿
    end
end

% =====================
% 6. 性能评估
% =====================
rmse_before = sqrt(mean((d_test - true_test).^2));
rmse_after  = sqrt(mean((corrected_distance - true_test).^2));
mae_before = mean(abs(d_test - true_test));
mae_after  = mean(abs(corrected_distance - true_test));

fprintf("补偿前 RMSE: %.3f m, MAE: %.3f m\n", rmse_before, mae_before);
fprintf("补偿后 RMSE: %.3f m, MAE: %.3f m\n", rmse_after, mae_after);

% =====================
% 7. 可视化
% =====================
figure;
scatter(true_test, d_test, 'r', 'filled'); hold on;
scatter(true_test, corrected_distance, 'b', 'filled');
plot([0 30], [0 30], 'k--', 'LineWidth', 1.5);
xlabel('真实距离 (m)');
ylabel('测量距离 (m)');
legend('原始测距', '补偿后', '理想', 'Location', 'best');
grid on;
title('UWB NLOS测距补偿效果');

%%
figure; hold on;

correct_idx = (y_pred_cls == y_test);
wrong_idx = (y_pred_cls ~= y_test);

% 预测正确的点
scatter(X_test(correct_idx & y_test==0, 1), X_test(correct_idx & y_test==0, 2), 'go', 'DisplayName', 'LOS 正确');
scatter(X_test(correct_idx & y_test==1, 1), X_test(correct_idx & y_test==1, 2), 'bo', 'DisplayName', 'NLOS 正确');

% 预测错误的点
scatter(X_test(wrong_idx & y_test==0, 1), X_test(wrong_idx & y_test==0, 2), 'gx', 'LineWidth', 2, 'DisplayName', 'LOS 错误');
scatter(X_test(wrong_idx & y_test==1, 1), X_test(wrong_idx & y_test==1, 2), 'bx', 'LineWidth', 2, 'DisplayName', 'NLOS 错误');

xlabel('时延扩展 (ns)');
ylabel('能量比例');
title('测试集分类结果（时延扩展 vs 能量比例）');
legend('Location', 'best');
grid on;
hold off;
