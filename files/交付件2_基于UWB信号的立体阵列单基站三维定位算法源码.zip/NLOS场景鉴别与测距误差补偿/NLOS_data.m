clc; clear; close all;

%% 假设数据已加载
% los_data  : 3729×100
% nlos_data : 3729×100
% 每列是一个CIR样本

% 加载数据（替换文件路径）
data_los = abs(load('LOS1.mat').h);
data_nlos = abs(load('NLOS1.mat').h);

num_los  = size(data_los, 2);
num_nlos = size(data_nlos, 2);

%% 1. 特征提取函数（均方时延扩展，能量比例，最大幅度）
extract_features = @(cir) [ ...
    compute_rms_delay(cir), ...                % 均方时延扩展
    sum(cir.^2) / sum(cir), ...                % 能量比例
    max(cir) ...                               % 最大幅度
];

function rms_delay = compute_rms_delay(cir)
    power = cir.^2;
    delays = (1:length(cir))';
    mean_delay = sum(power .* delays) / sum(power);
    rms_delay = sqrt(sum(power .* (delays - mean_delay).^2) / sum(power));
end

%% 2. 提取LOS特征
features_los = zeros(num_los, 3);
for i = 1:num_los
    features_los(i, :) = extract_features(data_los(:, i));
end

%% 3. 提取NLOS特征
features_nlos = zeros(num_nlos, 3);
for i = 1:num_nlos
    features_nlos(i, :) = extract_features(data_nlos(:, i));
end

%% 4. 组合数据与标签
X = [features_los; features_nlos];
y = [ones(num_los, 1); zeros(num_nlos, 1)]; % 1=LOS, 0=NLOS

%% 5. 划分训练/测试集（70%训练, 30%测试）
cv = cvpartition(y, 'HoldOut', 0.3);
X_train = X(training(cv), :);
y_train = y(training(cv));
X_test  = X(test(cv), :);
y_test  = y(test(cv));

%% 6. 训练 SVM
SVMModel = fitcsvm(X_train, y_train, 'KernelFunction', 'rbf', 'Standardize', true);

%% 7. 测试
y_pred = predict(SVMModel, X_test);

%% 8. 计算准确率
accuracy = sum(y_pred == y_test) / length(y_test);
fprintf('测试集分类准确率: %.2f%%\n', accuracy * 100);

%% 9. 可视化（用前两个特征：均方时延扩展 vs 能量比例）
figure;
gscatter(X_train(:,1), X_train(:,2), y_train, 'rb', 'ox');
xlabel('均方时延扩展');
ylabel('能量比例');
title('LOS/NLOS 特征分布（训练集）');

%% 10. 可视化混淆矩阵
figure;
cm = confusionchart(y_test, y_pred);
cm.Title = 'LOS/NLOS 分类混淆矩阵';
cm.RowSummary = 'row-normalized';
cm.ColumnSummary = 'column-normalized';

%% 11. 测试集分类结果可视化（均方时延扩展 vs 能量比例）
figure; hold on;

correct_idx = (y_pred == y_test);
wrong_idx = (y_pred ~= y_test);

% 正确分类
scatter(X_test(correct_idx & y_test==1, 1), X_test(correct_idx & y_test==1, 2), 'bo', 'DisplayName', 'LOS 正确');
scatter(X_test(correct_idx & y_test==0, 1), X_test(correct_idx & y_test==0, 2), 'ro', 'DisplayName', 'NLOS 正确');

% 错误分类
scatter(X_test(wrong_idx & y_test==1, 1), X_test(wrong_idx & y_test==1, 2), 'bx', 'LineWidth', 2, 'DisplayName', 'LOS 错误');
scatter(X_test(wrong_idx & y_test==0, 1), X_test(wrong_idx & y_test==0, 2), 'rx', 'LineWidth', 2, 'DisplayName', 'NLOS 错误');

xlabel('均方时延扩展');
ylabel('能量比例');
title('测试集分类结果（均方时延扩展 vs 能量比例）');
legend('Location', 'best');
grid on;
hold off;
