
%%�����ظ������ Soft Information 
function [SII0,SII1,mean01,mean02,mean11,mean12,SII0EfficRange0,SII0EfficRange1,SII1EfficRange0,SII1EfficRange1] = SIIFunction(PRI,ts,Nr,C)

%      PRI = 100e-9;
%      C = 3*10^8;
     t0 = ts:ts:20*PRI;
     t1 = ts:ts:20*PRI;
     deltaTOA = 20*2/C^2;                   % �������ķ��EbNOΪ15dBʱ����TOA���ĵķ���ȷ��
     
     % ��ǰһ�����ݽ��Ϊ0
     mean01 =  Nr*PRI;                     % ��һ����ֵ
     mean02 = (Nr+1/2)*PRI;            % �ڶ�����ֵ
     Gauss0 = 1/2*(1/(sqrt(3.1415926*deltaTOA)))*exp(-(((t0-mean01).^2)/(deltaTOA)))+1/2*(1/(sqrt(3.1415926*deltaTOA)))*exp(-(((t0- mean02).^2)/(deltaTOA))); 
     SII0 = Gauss0/max(Gauss0);       % ���Ŷ�
     % ��ǰһ�����ݽ��Ϊ1
     mean11 = (Nr-1/2)*PRI;            % ��һ����ֵ
     mean12 = Nr*PRI;                      % �ڶ�����ֵ     
     Gauss1 = 1/2*(1/(sqrt(3.1415926*deltaTOA)))*exp(-(((t1- mean11).^2)/(deltaTOA)))+1/2*(1/(sqrt(3.1415926*deltaTOA)))*exp(-(((t1- mean12).^2)/(deltaTOA))); 
     SII1 = Gauss1/max(Gauss1);   
     
     SII0EfficRange = find(abs(SII0-0.4)<0.005);
     SII0EfficRange0 = SII0EfficRange(1);
     SII0EfficRange1 = SII0EfficRange(end);
     SII1EfficRange = find(abs(SII1-0.4)<0.005);
     SII1EfficRange0 = SII1EfficRange(1);
     SII1EfficRange1 = SII1EfficRange(end);     
     
%      figure(1)
%      plot(t0,SII0,'LineWidth',2)
%      ax = gca;
%      ax.XAxis.Exponent = -9;
%      grid on 
%      
%      figure(2)
%      plot(t1,SII1,'LineWidth',2)
%      ax = gca;
%      ax.XAxis.Exponent = -9;
%      grid on
end