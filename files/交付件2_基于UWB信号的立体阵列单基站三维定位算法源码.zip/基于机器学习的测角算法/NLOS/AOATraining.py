import time
import pandas as pd
import torch
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, random_split
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
import re
from torch.utils.data import Dataset, DataLoader

import logging

from datetime import datetime

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_filename = f"model_training_{timestamp}.log"

logging.basicConfig(
    filename=log_filename,
    filemode='a',
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# 复数解析函数
def parse_complex(s):
    """解析多种格式的复数字符串，将其转换为 Python 复数对象"""
    # 将所有 'j' 替换为 'i'，并去掉任何外层的括号
    s = s.replace('j', 'i').strip('()')

    # 匹配复数格式：'a + bi', 'a-bi', 'a + bi', '(a+bi)'，并提取实部和虚部
    match = re.match(r'\s*([-+]?\d+\.?\d*)\s*([+-])\s*(\d+\.?\d*)i\s*', s)
    if match:
        real = float(match.group(1))
        imag = float(match.group(3)) * (1 if match.group(2) == '+' else -1)
        return complex(real, imag)
    else:
        # 如果不能匹配复数模式，尝试直接转换为实数
        try:
            return complex(float(s), 0)
        except ValueError:
            return complex(0, 0)  # 如果解析失败，返回 0 + 0j

# 数据集定义
class AOA_Dataset(Dataset):
    def __init__(self, csv_file):
        self.data = pd.read_csv(csv_file, header=None, skiprows=1)

        # 解析前50列中的复数
        self.data.iloc[:, 0:50] = self.data.iloc[:, 0:50].applymap(parse_complex)

        # 分离实部和虚部
        self.cir_real = self.data.iloc[:, 0:50].applymap(lambda z: z.real).values
        self.cir_imag = self.data.iloc[:, 0:50].applymap(lambda z: z.imag).values

        # PDOA 相关特征
        self.pdoa = self.data.iloc[:, 100].apply(parse_complex).apply(lambda z: z.real).values.reshape(-1, 1)
        self.other_features = self.data.iloc[:, 100:105].applymap(parse_complex).applymap(lambda z: z.real).values

        # 真实AOA标签
        self.labels = self.data.iloc[:, 105].apply(parse_complex).apply(lambda z: z.real).values

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # 将实部和虚部分开作为输入
        cir_real = torch.tensor(self.cir_real[idx], dtype=torch.float32).reshape(1, 50)
        cir_imag = torch.tensor(self.cir_imag[idx], dtype=torch.float32).reshape(1, 50)

        # 将实部和虚部拼接起来
        cir = torch.cat((cir_real, cir_imag), dim=0)  # 结果为 (2, 50) 的张量

        pdoa = torch.tensor(self.pdoa[idx], dtype=torch.float32)
        other_features = torch.tensor(self.other_features[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.float32)

        return cir, pdoa, other_features, label

# Transformer Encoder 定义
class TransformerEncoder(nn.Module):
    def __init__(self, embed_dim, n_heads, ff_dim, num_layers):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads, dim_feedforward=ff_dim)
            for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return self.norm(x)

# Dual Modal Model 定义
class DualModalModel(nn.Module):
    def __init__(self):
        super(DualModalModel, self).__init__()

        # Transformer Encoder 参数
        self.embed_dim = 128  # 嵌入维度
        self.n_heads = 4      # 注意力头数
        self.ff_dim = 128     # 前馈层维度
        self.num_layers = 2   # Transformer 层数

        # Transformer Encoder
        self.cir_transformer = TransformerEncoder(embed_dim=self.embed_dim, n_heads=self.n_heads, ff_dim=self.ff_dim, num_layers=self.num_layers)

        # CIR
        self.cir_conv = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2)
        )

        # PDOA
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),
            nn.ReLU()
        )

        # 融合层
        self.fc_fusion = nn.Sequential(
            nn.Linear(self.embed_dim + 32, 256),
            nn.ReLU(),
            nn.Linear(256, 1)  # 输出 AOA 预测
        )

    def forward(self, cir, pdoa, other_features):
        # CIR 模态前向传播
        cir_features = self.cir_conv(cir)  # CIR 输入 (batch_size, 2, 50)
        cir_features = cir_features.view(cir_features.size(0), -1)  # 展开为 (batch_size, 128 * 12)
        seq_len = cir_features.size(1) // self.embed_dim  # 动态计算 seq_len，确保总特征数与 embed_dim 对齐
        cir_features = cir_features.view(cir_features.size(0), seq_len, self.embed_dim)  # (batch_size, seq_len, embed_dim)

        # 通过 Transformer 编码器
        cir_features = self.cir_transformer(cir_features)  # (batch_size, seq_len, embed_dim)
        cir_features = cir_features.mean(dim=1)  # 聚合序列维度的特征

        # 处理 PDOA 和其他特征
        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_new = self.other_fc(other_features)

        # 融合特征
        combined_features = torch.cat((cir_features, other_features_new), dim=1)
        output = self.fc_fusion(combined_features)

        return output


if __name__ == '__main__':
    # # 设置数据集路径
    # csv_file = 'data_aoa1.csv'
    # dataset = AOA_Dataset(csv_file)
    #
    # # 设置随机数生成器以确保打乱一致性
    # g = torch.Generator()
    # g.manual_seed(42)  # 设置随机种子，确保打乱顺序可重复
    #
    # # 分割数据集：64% 训练集，16% 验证集，20% 测试集
    # train_size = int(0.64 * len(dataset))
    # val_size = int(0.16 * len(dataset))
    # test_size = len(dataset) - train_size - val_size
    # train_dataset, val_dataset, test_dataset = random_split(dataset, [train_size, val_size, test_size], generator=g)
    #
    # # 将训练、验证、测试数据保存为 CSV
    # train_df = pd.DataFrame(dataset.data.iloc[train_dataset.indices])
    # val_df = pd.DataFrame(dataset.data.iloc[val_dataset.indices])
    # test_df = pd.DataFrame(dataset.data.iloc[test_dataset.indices])
    #
    # train_df.to_csv('train_data.csv', index=False)
    # val_df.to_csv('val_data.csv', index=False)
    # test_df.to_csv('test_data.csv', index=False)
    #
    # # 加载训练集、验证集和测试集
    # train_dataloader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    # val_dataloader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    # test_dataloader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    # 加载测试集数据
    test_csv_file = 'test_data.csv'
    test_dataset = AOA_Dataset(test_csv_file)
    test_dataloader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    train_csv_file = 'train_data.csv'
    train_dataset = AOA_Dataset(train_csv_file)
    train_dataloader = DataLoader(train_dataset, batch_size=32, shuffle=True)

    val_csv_file = 'val_data.csv'
    val_dataset = AOA_Dataset(val_csv_file)
    val_dataloader = DataLoader(val_dataset, batch_size=32, shuffle=False)

    csv_file = 'data_aoa1.csv'
    dataset = AOA_Dataset(csv_file)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=False)

    # 模型实例化
    model = DualModalModel()

    # 计算模型的参数量
    def count_parameters(model):
        return sum(p.numel() for p in model.parameters() if p.requires_grad)

    param_count = count_parameters(model)
    print(f"模型的参数量为：{param_count} 个参数")
    logging.info(f'参数量 [{param_count:.2f} 个参数]')

    # 定义损失函数和优化器
    criterion = torch.nn.L1Loss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    # 绘制收敛曲线的函数
    def plot_loss(train_losses, val_losses):
        plt.figure(figsize=(10,6))
        plt.plot(train_losses, label='Train Loss')
        plt.plot(val_losses, label='Validation Loss')
        plt.title('Training and Validation Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend()
        plt.show()

    # 绘制散点图
    def plot_est_vs_true(all_preds, all_labels):
        plt.figure(figsize=(8, 6))
        plt.scatter(all_labels, all_preds, alpha=0.5, label='Estimated AOA vs True AOA')
        plt.plot([min(all_labels), max(all_labels)], [min(all_labels), max(all_labels)], 'r--')
        plt.title('Estimated AOA vs True AOA')
        plt.xlabel('True AOA')
        plt.ylabel('Estimated AOA')
        plt.legend()
        plt.show()

    # 绘制误差棒图
    def plot_error_bars(true_aoa, est_aoa, std_devs):
        plt.figure(figsize=(8, 6))
        plt.errorbar(true_aoa, est_aoa, yerr=std_devs, fmt='o', label='Mean with STD')
        plt.title('Estimated AOA with Error Bars (STD)')
        plt.xlabel('True AOA')
        plt.ylabel('Estimated AOA')
        plt.legend()
        plt.show()

    # 在定义优化器之后加入学习率调度器
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10, verbose=True)

    # 在训练过程中加入调度器
    def train_model_with_plots(model, train_dataloader, val_dataloader, test_dataloader, criterion, optimizer, scheduler, num_epochs=200):
        train_losses = []
        val_losses = []

        for epoch in range(num_epochs):
            # 训练阶段
            model.train()
            running_loss = 0.0
            all_preds, all_labels = [], []

            for cir, pdoa, other_features, label in train_dataloader:
                optimizer.zero_grad()

                # 前向传播
                output = model(cir, pdoa, other_features)
                loss = criterion(output.squeeze(), label)

                # 反向传播
                loss.backward()
                optimizer.step()

                running_loss += loss.item()

                # 累积预测和真实值用于计算 MAE 和 STD
                all_preds.extend(output.detach().cpu().numpy().flatten())
                all_labels.extend(label.cpu().numpy().flatten())

            # 记录训练损失和 MAE/STD
            train_loss = running_loss / len(train_dataloader)
            train_mae = np.mean(np.abs(np.array(all_preds) - np.array(all_labels)))
            train_std = np.std(np.array(all_preds) - np.array(all_labels))
            train_losses.append(train_loss)

            print(f'Epoch [{epoch+1}/{num_epochs}], Training Loss: {train_loss:.4f}, MAE: {train_mae:.4f}, STD: {train_std:.4f}')


            # 验证阶段
            model.eval()
            val_loss = 0.0
            val_preds, val_labels = [], []

            with torch.no_grad():
                for cir, pdoa, other_features, label in val_dataloader:
                    output = model(cir, pdoa, other_features)
                    loss = criterion(output.squeeze(), label)
                    val_loss += loss.item()

                    val_preds.extend(output.cpu().numpy().flatten())
                    val_labels.extend(label.cpu().numpy().flatten())

            # 记录验证损失和 MAE/STD
            val_loss /= len(val_dataloader)
            val_mae = np.mean(np.abs(np.array(val_preds) - np.array(val_labels)))
            val_std = np.std(np.array(val_preds) - np.array(val_labels))
            val_losses.append(val_loss)

            print(f'Epoch [{epoch+1}/{num_epochs}], Validation Loss: {val_loss:.4f}, MAE: {val_mae:.4f}, STD: {val_std:.4f}')
            # Logging the epoch progress
            logging.info(f'Epoch [{epoch + 1}/{num_epochs}], Train Loss: {running_loss / len(train_dataloader):.4f}, '
                         f'Validation Loss: {val_loss / len(val_dataloader):.4f}')

            # 调整学习率
            scheduler.step(val_loss)

        # 保存模型
        torch.save(model.state_dict(), 'dual_modal_model_1117.pth')
        logging.info("Model saved as 'dual_modal_model_1117.pth'.")

        # 绘制收敛曲线
        plot_loss(train_losses, val_losses)

        # 绘制散点图和误差棒图
        plot_est_vs_true(val_preds, val_labels)
        plot_error_bars(val_labels, val_preds, np.std(np.array(val_preds) - np.array(val_labels)))

        return model

    # 开始训练并评估模型
    start_time = time.time()
    train_model_with_plots(model, train_dataloader, val_dataloader, test_dataloader, criterion, optimizer, scheduler, num_epochs=200)
    end_time = time.time()

    training_time = end_time - start_time
    print(f"Total Training Time: {training_time:.2f} seconds")
    logging.info(f'Training Time [{training_time:.2f} seconds]')

    # 加载保存的模型进行测试
    def evaluate_on_test_set(model, test_dataloader):
        model.eval()
        test_loss = 0.0
        test_preds, test_labels = [], []

        with torch.no_grad():
            for cir, pdoa, other_features, label in test_dataloader:
                output = model(cir, pdoa, other_features)
                loss = criterion(output.squeeze(), label)
                test_loss += loss.item()

                test_preds.extend(output.cpu().numpy().flatten())
                test_labels.extend(label.cpu().numpy().flatten())

        # 计算测试集上的 MAE 和 STD
        test_loss /= len(test_dataloader)
        test_mae = np.mean(np.abs(np.array(test_preds) - np.array(test_labels)))
        test_std = np.std(np.array(test_preds) - np.array(test_labels))

        print(f"Test Loss: {test_loss:.4f}, Test MAE: {test_mae:.4f}, Test STD: {test_std:.4f}")
        logging.info(f'Testing MAE [{test_mae:.4f}]')
        logging.info(f'Testing STD [{test_std:.4f}]')


    # 使用测试集评估
    start_time_test = time.time()
    evaluate_on_test_set(model, test_dataloader)
    end_time_test = time.time()

    training_time_test = end_time_test - start_time_test
    print(f"Total Testing Time: {training_time_test:.2f} seconds")
    logging.info(f'Testing Time [{training_time_test:.2f} seconds]')

