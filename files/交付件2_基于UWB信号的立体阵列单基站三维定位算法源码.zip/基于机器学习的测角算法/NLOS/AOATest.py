import torch
import pandas as pd
import matplotlib.pyplot as plt
import time
import pandas as pd
import torch
import numpy as np
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, random_split
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
import re
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# 复数解析函数
import re



def parse_complex(s):
    """解析多种格式的复数字符串，将其转换为 Python 复数对象"""
    # 将所有 'j' 替换为 'i'，并去掉任何外层的括号
    s = s.replace('j', 'i').strip('()')

    # 匹配复数格式：'a + bi', 'a-bi', 'a + bi', '(a+bi)'，并提取实部和虚部
    match = re.match(r'\s*([-+]?\d+\.?\d*)\s*([+-])\s*(\d+\.?\d*)i\s*', s)
    if match:
        real = float(match.group(1))
        imag = float(match.group(3)) * (1 if match.group(2) == '+' else -1)
        return complex(real, imag)
    else:
        # 如果不能匹配复数模式，尝试直接转换为实数
        try:
            return complex(float(s), 0)
        except ValueError:
            return complex(0, 0)  # 如果解析失败，返回 0 + 0j


# 数据集定义
class AOA_Dataset(Dataset):
    def __init__(self, csv_file):
        # 读取CSV数据，跳过第一行
        self.data = pd.read_csv(csv_file, header=None, skiprows=1)

        # 解析前50列中的复数
        self.data.iloc[:, 0:50] = self.data.iloc[:, 0:50].applymap(parse_complex)

        # 分离实部和虚部
        self.cir_real = self.data.iloc[:, 0:50].applymap(lambda z: z.real).values
        self.cir_imag = self.data.iloc[:, 0:50].applymap(lambda z: z.imag).values

        # PDOA 相关特征 (假设在第100列之后)
        self.pdoa = self.data.iloc[:, 100].apply(parse_complex).apply(lambda z: z.real).values.reshape(-1, 1)
        self.other_features = self.data.iloc[:, 100:105].applymap(parse_complex).applymap(lambda z: z.real).values

        # 真实AOA标签 (第106列)
        self.labels = self.data.iloc[:, 105].apply(parse_complex).apply(lambda z: z.real).values

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        # 将实部和虚部分开作为输入
        cir_real = torch.tensor(self.cir_real[idx], dtype=torch.float32).reshape(1, 50)
        cir_imag = torch.tensor(self.cir_imag[idx], dtype=torch.float32).reshape(1, 50)

        # 将实部和虚部拼接起来
        cir = torch.cat((cir_real, cir_imag), dim=0)  # 结果为 (2, 50) 的张量

        pdoa = torch.tensor(self.pdoa[idx], dtype=torch.float32)
        other_features = torch.tensor(self.other_features[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.float32)

        return cir, pdoa, other_features, label


# Transformer Encoder 定义
class TransformerEncoder(nn.Module):
    def __init__(self, embed_dim, n_heads, ff_dim, num_layers):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(d_model=embed_dim, nhead=n_heads, dim_feedforward=ff_dim)
            for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return self.norm(x)


# Dual Modal Model 定义
class DualModalModel(nn.Module):
    def __init__(self):
        super(DualModalModel, self).__init__()

        # Transformer Encoder 参数
        self.embed_dim = 128  # 嵌入维度
        self.n_heads = 4  # 注意力头数
        self.ff_dim = 128  # 前馈层维度
        self.num_layers = 2  # Transformer 层数

        # Transformer Encoder
        self.cir_transformer = TransformerEncoder(embed_dim=self.embed_dim, n_heads=self.n_heads, ff_dim=self.ff_dim,
                                                  num_layers=self.num_layers)

        # CIR 模态: 使用卷积层提取特征
        self.cir_conv = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2)
        )

        # PDOA 模态: 处理 PDOA 和其他相关特征
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),  # 假设 other_features_dim 是其他特征的输入维度
            nn.ReLU()
        )

        # 融合层
        self.fc_fusion = nn.Sequential(
            nn.Linear(self.embed_dim + 32, 256),  # 根据新特征维度进行调整
            nn.ReLU(),
            nn.Linear(256, 1)  # 输出 AOA 预测
        )

    def forward(self, cir, pdoa, other_features):
        # CIR 模态前向传播
        cir_features = self.cir_conv(cir)  # CIR 输入 (batch_size, 2, 50)
        cir_features = cir_features.view(cir_features.size(0), -1)  # 展开为 (batch_size, 128 * 12)
        seq_len = cir_features.size(1) // self.embed_dim  # 动态计算 seq_len，确保总特征数与 embed_dim 对齐
        cir_features = cir_features.view(cir_features.size(0), seq_len,
                                         self.embed_dim)  # (batch_size, seq_len, embed_dim)

        # 通过 Transformer 编码器
        cir_features = self.cir_transformer(cir_features)  # (batch_size, seq_len, embed_dim)
        cir_features = cir_features.mean(dim=1)  # 聚合序列维度的特征

        # 处理 PDOA 和其他特征
        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_new = self.other_fc(other_features)

        # 融合特征
        combined_features = torch.cat((cir_features, other_features_new), dim=1)
        output = self.fc_fusion(combined_features)

        return output

class DualModal_LSTMModel(nn.Module):
    def __init__(self, hidden_size, num_layers, other_feature_size):
        super(DualModal_LSTMModel, self).__init__()

        # LSTM input size should be 2 (real and imaginary parts)
        input_size = 2

        # Correctly define LSTM: input_size should be 2
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc_lstm = nn.Linear(hidden_size, 128)

        # Fully connected for PDOA processing
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        # Adjust the input size for the `other_fc` layer to 5
        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),  # Match input size to 5 based on other_features
            nn.ReLU()
        )

        # Fusion layer
        self.fc_fusion = nn.Sequential(
            nn.Linear(128 + 32, 256),
            nn.ReLU(),
            nn.Linear(256, 1)  # Output AOA prediction
        )

    def forward(self, cir, pdoa, other_features):
        batch_size = cir.size(0)

        # Ensure CIR input has the correct dimensions: (batch_size, seq_len=50, input_size=2)
        cir_features = cir.permute(0, 2, 1)  # Adjust input to (batch_size, 50, 2)

        # Initialize hidden and cell states with correct dimensions
        h0 = torch.zeros(2, batch_size, hidden_size).to(cir.device)  # (num_layers, batch_size, hidden_size)
        c0 = torch.zeros(2, batch_size, hidden_size).to(cir.device)

        # Pass through LSTM
        lstm_out, _ = self.lstm(cir_features, (h0, c0))
        cir_out = self.fc_lstm(lstm_out[:, -1, :])  # Use the last time step output

        # Process PDOA and other features
        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_out = self.other_fc(other_features)

        # Fusion of features
        combined_features = torch.cat((cir_out, other_features_out), dim=1)
        output = self.fc_fusion(combined_features)

        return output

class ResBlock1D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(ResBlock1D, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size, stride, padding)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size, stride, padding)
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.shortcut = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        shortcut = self.shortcut(x)
        out += shortcut
        return F.relu(out)

class DualModal_ResNetModel(nn.Module):
    def __init__(self, other_feature_size):
        super(DualModal_ResNetModel, self).__init__()
        # ResNet for CIR processing
        self.resnet = nn.Sequential(
            ResBlock1D(2, 64),
            ResBlock1D(64, 128),
            nn.AdaptiveAvgPool1d(1),  # Pooling to get a fixed feature size
        )
        self.fc_resnet = nn.Linear(128, 128)

        # Fully connected for PDOA processing
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),
            nn.ReLU()
        )

        # Fusion layer
        self.fc_fusion = nn.Sequential(
            nn.Linear(128 + 32, 256),
            nn.ReLU(),
            nn.Linear(256, 1)  # Output AOA prediction
        )

    def forward(self, cir, pdoa, other_features):
        cir_features = self.resnet(cir)
        cir_out = cir_features.view(cir_features.size(0), -1)
        cir_out = self.fc_resnet(cir_out)

        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_out = self.other_fc(other_features)

        combined_features = torch.cat((cir_out, other_features_out), dim=1)
        output = self.fc_fusion(combined_features)
        return output


class SimplifiedModalModel(nn.Module):
    def __init__(self):
        super(SimplifiedModalModel, self).__init__()

        # Process PDOA feature
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        # Process other features
        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),
            nn.ReLU()
        )

        # Fusion layer
        self.fc_fusion = nn.Sequential(
            nn.Linear(16 + 32, 256),
            nn.ReLU(),
            nn.Linear(256, 1)  # Output AOA prediction
        )

    def forward(self, pdoa, other_features):
        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_out = self.other_fc(other_features)

        # Combine the processed features
        combined_features = torch.cat((pdoa_feature, other_features_out), dim=1)
        output = self.fc_fusion(combined_features)

        return output

class CNNModel(nn.Module):
    def __init__(self):
        super(CNNModel, self).__init__()

        # CIR 模态: 使用卷积层提取特征
        self.cir_conv = nn.Sequential(
            nn.Conv1d(in_channels=2, out_channels=32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(in_channels=32, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2),
            nn.Conv1d(in_channels=64, out_channels=128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2)
        )

        # PDOA 模态: 处理 PDOA 和其他相关特征
        self.pdoa_fc = nn.Sequential(
            nn.Linear(1, 16),
            nn.ReLU()
        )

        self.other_fc = nn.Sequential(
            nn.Linear(5, 32),  # 假设 other_features_dim 是其他特征的输入维度
            nn.ReLU()
        )

        # 融合层
        self.fc_fusion = nn.Sequential(
            nn.Linear(768 + 32, 256),  # 根据新特征维度进行调整
            nn.ReLU(),
            nn.Linear(256, 1)  # 输出 AOA 预测
        )

    def forward(self, cir, pdoa, other_features):
        # CIR 模态前向传播
        cir_features = self.cir_conv(cir)  # CIR 输入 (batch_size, 2, 50)
        cir_features = cir_features.view(cir_features.size(0), -1)  # 展开为 (batch_size, 128 * 12)
        # print("CIR Features shape:", cir_features.shape)  # 调试用
        # 处理 PDOA 和其他特征
        pdoa_feature = self.pdoa_fc(pdoa)
        other_features_new = self.other_fc(other_features)

        # 融合特征
        combined_features = torch.cat((cir_features, other_features_new), dim=1)
        output = self.fc_fusion(combined_features)

        return output

if __name__ == '__main__':
    # 定义损失函数（在评估时会用到）
    criterion = torch.nn.L1Loss()

    # 加载保存的模型.
    # CNN
    # model = CNNModel()
    # model.load_state_dict(torch.load('dual_modal_model_1117.pth'))

    # Transformer
    model = DualModalModel()
    model.load_state_dict(torch.load('dual_modal_model.pth'))

    ## LSTM
    # hidden_size = 64  # Adjust based on your needs
    # num_layers = 2  # Number of layers in LSTM
    # other_feature_size = 5  # Update to match your actual other features count
    # model = DualModal_LSTMModel(hidden_size, num_layers, other_feature_size)
    # model.load_state_dict(torch.load('dual_modal_lstm_model.pth'))

    #resnet
    other_feature_size = 5
    # model = DualModal_ResNetModel(other_feature_size)
    # model.load_state_dict(torch.load('dual_modal_resnet_model.pth'))

    #dnn
    # model = SimplifiedModalModel()
    # model.load_state_dict(torch.load('simplified_modal_model.pth'))

    model.eval()

    # 加载测试集数据
    test_csv_file = 'test_data.csv'
    test_dataset = AOA_Dataset(test_csv_file)
    test_dataloader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    val_csv_file = 'val_data.csv'
    val_dataset = AOA_Dataset(val_csv_file)
    val_dataloader = DataLoader(val_dataset, batch_size=32, shuffle=False)

    train_csv_file = 'train_data.csv'
    train_dataset = AOA_Dataset(train_csv_file)
    train_dataloader = DataLoader(train_dataset, batch_size=32, shuffle=False)

    csv_file = 'data_aoa1.csv'
    dataset = AOA_Dataset(csv_file)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=False)


    # 评估模型并收集真实 AOA 和预测 AOA
    def evaluate_and_collect_data(model, test_dataloader):
        model.eval()
        all_true_aoa = []
        all_pdoa = []
        all_pred_aoa = []

        with torch.no_grad():
            for cir, pdoa, other_features, label in test_dataloader:
                # 模型前向传播得到预测
                pred_aoa = model(cir, pdoa, other_features)
                # pred_aoa = model(pdoa,other_features)

                # 收集数据
                all_true_aoa.extend(label.cpu().numpy().flatten())  # 真实的 AOA
                all_pdoa.extend(pdoa.cpu().numpy().flatten())  # PDOA 数据
                all_pred_aoa.extend(pred_aoa.cpu().numpy().flatten())  # 预测的 AOA

        return all_true_aoa, all_pdoa, all_pred_aoa


    def evaluate_on_train_set(model, train_dataloader):
        model.eval()
        train_loss = 0.0
        train_preds, train_labels = [], []

        with torch.no_grad():
            for cir, pdoa, other_features, label in train_dataloader:
                output = model(cir, pdoa, other_features)
                # output = model(pdoa, other_features)
                loss = criterion(output.squeeze(), label)
                train_loss += loss.item()

                train_preds.extend(output.cpu().numpy().flatten())
                train_labels.extend(label.cpu().numpy().flatten())

        # 计算测试集上的 MAE 和 STD
        train_loss /= len(train_dataloader)
        train_mae = np.mean(np.abs(np.array(train_preds) - np.array(train_labels)))
        train_std = np.std(np.array(train_preds) - np.array(train_labels))
        train_rmse = np.sqrt(np.mean((np.array(train_preds) - np.array(train_labels)) ** 2))
        errors_train = np.abs(np.array(train_preds) - np.array(train_labels))
        # 计算 3° 和 5° 内的占比
        within_3_deg = np.sum(errors_train <= 3) / len(errors_train) * 100
        within_5_deg = np.sum(errors_train <= 5) / len(errors_train) * 100
        # 输出 3° 和 5° 内的占比
        print(f'训练集3°内的MAE占比: {within_3_deg:.2f}%')
        print(f'训练集5°内的MAE占比: {within_5_deg:.2f}%')
        print(f"Train MAE: {train_mae:.4f},Train RMSE: {train_rmse}, Train STD: {train_std:.4f}")

    def evaluate_on_val_set(model, val_dataloader):
        model.eval()
        val_loss = 0.0
        val_preds, val_labels = [], []

        with torch.no_grad():
            for cir, pdoa, other_features, label in val_dataloader:
                output = model(cir, pdoa, other_features)
                # output = model(pdoa, other_features)
                loss = criterion(output.squeeze(), label)
                val_loss += loss.item()

                val_preds.extend(output.cpu().numpy().flatten())
                val_labels.extend(label.cpu().numpy().flatten())

        # 计算测试集上的 MAE 和 STD
        val_loss /= len(val_dataloader)
        val_mae = np.mean(np.abs(np.array(val_preds) - np.array(val_labels)))
        val_std = np.std(np.array(val_preds) - np.array(val_labels))
        val_rmse = np.sqrt(np.mean((np.array(val_preds) - np.array(val_labels)) ** 2))
        errors_val = np.abs(np.array(val_preds) - np.array(val_labels))
        # 计算 3° 和 5° 内的占比
        within_3_deg = np.sum(errors_val <= 3) / len(errors_val) * 100
        within_5_deg = np.sum(errors_val <= 5) / len(errors_val) * 100
        # 输出 3° 和 5° 内的占比
        # print(f'训练集3°内的MAE占比: {within_3_deg:.2f}%')
        # print(f'训练集5°内的MAE占比: {within_5_deg:.2f}%')
        print(f"VAL MAE: {val_mae:.4f},VAL RMSE: {val_rmse}, VAL STD: {val_std:.4f}")
    def evaluate_on_test_set(model, test_dataloader):
        model.eval()
        test_loss = 0.0
        test_preds, test_labels,test_pdoa = [], [], []

        with torch.no_grad():
            for cir, pdoa, other_features, label in test_dataloader:
                output = model(cir, pdoa, other_features)
                # output = model( pdoa, other_features)
                loss = criterion(output.squeeze(), label)
                test_loss += loss.item()

                test_preds.extend(output.cpu().numpy().flatten())
                test_labels.extend(label.cpu().numpy().flatten())
                test_pdoa.extend(pdoa.cpu().numpy().flatten())

        # 计算测试集上的 MAE 和 STD
        test_loss /= len(test_dataloader)
        test_mae = np.mean(np.abs(np.array(test_preds) - np.array(test_labels)))
        test_std = np.std(np.array(test_preds) - np.array(test_labels))
        pdoa_std = np.std(np.abs(np.array(test_pdoa) - np.array(test_labels)))
        test_pdoa_mae = np.mean(np.abs(np.array(test_pdoa) - np.array(test_labels)))
        test_rmse = np.sqrt(np.mean((np.array(test_preds) - np.array(test_labels)) ** 2))
        test_pdoa_rmse = np.sqrt(np.mean((np.array(test_pdoa) - np.array(test_labels)) ** 2))
        errors = np.abs(np.array(test_preds) - np.array(test_labels))
        errors_pdoa = np.abs(np.array(test_preds) - np.array(test_pdoa))

        # 计算 3° 和 5° 内的占比
        within_3_deg = np.sum(errors <= 3) / len(errors) * 100
        within_5_deg = np.sum(errors <= 5) / len(errors) * 100
        within_3_deg_pdoa = np.sum(errors_pdoa <= 3) / len(errors_pdoa) * 100
        within_5_deg_pdoa = np.sum(errors_pdoa <= 5) / len(errors_pdoa) * 100

        # 输出 3° 和 5° 内的占比
        print(f'3°内的MAE占比: {within_3_deg:.2f}%')
        print(f'5°内的MAE占比: {within_5_deg:.2f}%')
        print(f'PDOA估计的AOA3°内的MAE占比: {within_3_deg_pdoa:.2f}%')
        print(f'PDOA估计的AOA5°内的MAE占比: {within_5_deg_pdoa:.2f}%')
        print(f"Test RMSE: {test_rmse}")
        print(f"Test PDOA RMSE: {test_pdoa_rmse}")
        print(f"Test PDOA MAE: {test_pdoa_mae:.4f}, Test MAE: {test_mae:.4f}, Test STD: {test_std:.4f}")
        print(f"Test PDOA STD: {pdoa_std}")


    # 获取评估数据
    true_aoa, pdoa, pred_aoa = evaluate_and_collect_data(model, test_dataloader)
    start_time_test = time.time()
    evaluate_on_test_set(model, test_dataloader)
    end_time_test = time.time()
    training_time_test = end_time_test - start_time_test
    print(f"Total Testing Time: {training_time_test:.2f} seconds")
    evaluate_on_train_set(model, train_dataloader)
    evaluate_on_val_set(model, val_dataloader)


    # 绘制图 1：真实 AOA 与 PDOA 的散点图
    def plot_aoa_vs_pdoa(true_aoa, pdoa):
        plt.figure(figsize=(8, 6))
        plt.scatter(true_aoa, pdoa, alpha=0.5, label='PDOA估计的AOA', color='skyblue')
        plt.plot([min(true_aoa), max(true_aoa)], [min(true_aoa), max(true_aoa)], 'k--', label='参考值')
        plt.title('True AOA vs PDOA')
        plt.xlabel('真实的AOA(°)')
        plt.ylabel('PDOA估计的AOA(°)')
        plt.grid(False)  # 关闭网格线
        plt.legend()
        plt.show()


    # 绘制图 2：真实 AOA 与预测 AOA 的散点图
    def plot_aoa_vs_pred_aoa(true_aoa, pred_aoa):
        plt.figure(figsize=(8, 6))
        plt.scatter(true_aoa, pred_aoa, alpha=0.5, label='特征融合（CNN+Transformer编码器）估计的AOA', color='skyblue')  # 将点改为天蓝色
        plt.plot([min(true_aoa), max(true_aoa)], [min(true_aoa), max(true_aoa)], 'k--', label='参考值')  # 参考线为黑色虚线
        # plt.title('双模态Transformer估计的AOA')
        plt.xlabel('真实的AOA(°)')
        plt.ylabel('特征融合模型估计的AOA(°)')
        plt.grid(False)  # 关闭网格线
        plt.legend()
        plt.show()


    # 绘制两个图
    plt.rcParams['font.size'] = 16  # 调整全局字体大小
    plt.rcParams['font.family'] = ['SimHei']  # 使用黑体
    plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号
    plot_aoa_vs_pdoa(true_aoa, pdoa)
    plot_aoa_vs_pred_aoa(true_aoa, pred_aoa)
    plt.show()

