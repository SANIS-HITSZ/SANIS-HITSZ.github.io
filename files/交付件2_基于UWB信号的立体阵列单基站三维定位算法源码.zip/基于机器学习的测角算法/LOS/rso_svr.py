"""
RSO-SVR：基于鼠群优化器（Rat Swarm Optimizer）的支持向量回归
用于 UWB 到达角（AOA）估计

参考文献：
    A Robust Machine Learning Based UWB AOA Estimation Method
    (IEEE VTC2024-Spring, DOI: 10.1109/VTC2024-SPRING62846.2024.10683435)

----------------------------------------------------------------------
模型输入特征（6个，论文第III节）：
    F1 : PDOA-AOA 粗估计        = arcsin(λ·Δφ / (2π·d))
    F2 : 接收功率差             = P1 - P2
    F3 : 首径幅度差             = FPA1 - FPA2
    F4 : 首径功率差             = FPP1 - FPP2
    F5 : 幅度比差               = FPA1/MA1 - FPA2/MA2
    F6 : 两天线CIR相关系数实部  = Re(Cov(CIR1,CIR2) / sqrt(Var1·Var2))

    注：FPA、MA 由CIR计算；FPP、P 由寄存器直接读取。
    论文最终选用 F1、F3、F4、F6 作为输入，此处保留全部6维。

----------------------------------------------------------------------
数据集列定义（0索引，共113列）：
    列 0   - 49  : CIR1，天线1接收的50个复数CIR样本
    列 50  - 99  : CIR2，天线2接收的50个复数CIR样本
    列 100        : 传感器测距结果（单位 mm）
    列 101 - 104  : 4个时间戳（不使用）
    列 105        : PDOA（相位差，DW3220寄存器原始值）
    列 106        : TDOA（时间差，不使用）
    列 107        : P1（天线1接收信号功率，dBm）
    列 108        : P2（天线2接收信号功率，dBm）
    列 109        : FPP1（天线1首径功率）
    列 110        : FPP2（天线2首径功率）
    列 111        : 距离真实值（单位 m）
    列 112        : 到达角真实值（单位 °）

----------------------------------------------------------------------
输出文件 rso-svr.csv（无表头，4列）：
    列0 : dist_sensor_m   传感器测距（m）
    列1 : dist_label_m    距离真实值（m）
    列2 : angle_pred_deg  SVR角度预测（°）
    列3 : angle_label_deg 角度真实值（°）

    前段：同源测试集（datasets-2d-azi.csv 的 15%）
    后段：非同源测试集（datasets-3d-azi-out.csv 全部）
"""

import ast
import csv
import warnings

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

warnings.filterwarnings("ignore")


# ============================================================
# 硬件参数（DW3220，UWB信道5）
# ============================================================
FREQ_HZ     = 6.4896e9         # 中心频率 6489.6 MHz
LAMBDA_M    = 3e8 / FREQ_HZ    # 波长 ≈ 0.04623 m
ANTENNA_D_M = 0.02             # 天线间距 2 cm（论文设置）

# DW3220 IP_PDOA 寄存器：13位有符号整数
# 范围 -4096 ~ +4096 对应 -π ~ +π rad
PDOA_SCALE = np.pi / 4096      # 每个LSB对应的弧度值


# ============================================================
# 1.  从 CIR 提取首径幅度（FPA）和最大幅度（MA）
# ============================================================

def compute_FPA(cir_complex, threshold_ratio=0.6):
    """
    首径幅度（First Path Amplitude, FPA）。

    CIR已按 [FP-10, FP+39] 截窗（共50点），首径峰值在索引10附近。
    取第一个超过 peak×threshold_ratio 的样本幅度，
    代表最早到达的多径分量的幅度。
    """
    amplitude = np.abs(cir_complex)
    max_amp = amplitude.max()
    if max_amp < 1e-10:
        return 0.0
    indices = np.where(amplitude >= threshold_ratio * max_amp)[0]
    return float(amplitude[indices[0]]) if len(indices) else 0.0


def compute_MA(cir_complex):
    """最大幅度（Maximum Amplitude, MA）：|CIR| 的峰值。"""
    return float(np.abs(cir_complex).max())


# ============================================================
# 2.  六个输入特征的计算（论文公式4-9）
# ============================================================

def compute_F1(pdoa_raw):
    """
    F1：基于PDOA的AOA粗估计（单位：°）。
    论文公式(4)：F1 = arcsin(λ·Δφ / (2π·d))
    Δφ = pdoa_raw × PDOA_SCALE（单位：rad）
    对 arcsin 的参数裁剪到 [-1, 1] 以防数值溢出。
    """
    delta_phi = pdoa_raw * PDOA_SCALE
    arg = LAMBDA_M * delta_phi / (2 * np.pi * ANTENNA_D_M)
    arg = float(np.clip(arg, -1.0, 1.0))
    return float(np.degrees(np.arcsin(arg)))


def compute_F2(p1, p2):
    """
    F2：接收信号功率差（单位：dBm）。
    论文公式(5)：F2 = P1 - P2
    """
    return float(p1 - p2)


def compute_F3(fpa1, fpa2):
    """
    F3：首径幅度差。
    论文公式(6)：F3 = FPA1 - FPA2
    """
    return float(fpa1 - fpa2)


def compute_F4(fpp1, fpp2):
    """
    F4：首径功率差（单位：dBm）。
    论文公式(7)：F4 = FPP1 - FPP2
    """
    return float(fpp1 - fpp2)


def compute_F5(fpa1, fpa2, ma1, ma2):
    """
    F5：幅度比差。
    论文公式(8)：F5 = FPA1/MA1 - FPA2/MA2
    衡量两天线CIR中首径幅度占最大幅度的比值之差。
    """
    r1 = fpa1 / ma1 if ma1 > 1e-10 else 0.0
    r2 = fpa2 / ma2 if ma2 > 1e-10 else 0.0
    return float(r1 - r2)


def compute_F6(cir1, cir2):
    """
    F6：两天线CIR复相关系数的实部（RCORR）。
    论文公式(9)：
        Cov(CIR1, CIR2) = 1/(N-1) × Σ (CIR1_i - μ1)(CIR2_i - μ2)
        F6 = Re( Cov / sqrt(Var(CIR1) × Var(CIR2)) )

    注：Cov使用复数直接相乘（无共轭），不同于Pearson相关系数。
        Var 使用 |·|² 保证为实数。
    """
    N = len(cir1)
    mu1, mu2 = np.mean(cir1), np.mean(cir2)
    c1, c2 = cir1 - mu1, cir2 - mu2

    cov  = np.sum(c1 * c2) / (N - 1)           # 复数协方差（无共轭）
    var1 = np.sum(np.abs(c1) ** 2) / (N - 1)   # 幅度方差（实数）
    var2 = np.sum(np.abs(c2) ** 2) / (N - 1)

    denom = np.sqrt(var1 * var2)
    if denom < 1e-10:
        return 0.0
    return float(np.real(cov / denom))


# ============================================================
# 3.  数据加载
# ============================================================

def load_dataset(filepath):
    """
    从CSV文件读取数据，提取6维特征向量和标签。

    返回
    ----
    X           : ndarray (N, 6)  特征矩阵 [F1, F2, F3, F4, F5, F6]
    y_angle     : ndarray (N,)    角度真实值（°）
    y_dist      : ndarray (N,)    距离真实值（m）
    dist_sensor : ndarray (N,)    传感器测距结果（m）
    """
    df = pd.read_csv(filepath, header=None, dtype=str)
    N = len(df)
    print(f"  读取 {N} 条样本，来源：{filepath}")

    X_list, y_angle_list, y_dist_list, dist_sensor_list = [], [], [], []
    n_skip = 0

    for _, row in df.iterrows():
        pts = row.tolist()
        try:
            # ---------- 解析CIR复数数据（前100列）----------
            cir = np.array(
                [ast.literal_eval(p) for p in pts[:100]], dtype=np.complex64
            )
            cir1, cir2 = cir[:50], cir[50:]  # 天线1和天线2各50点

            # ---------- 解析实数列（列100起）----------
            real = [float(p) for p in pts[100:]]
            dist_sensor_m = real[0] / 1000.0   # 列100：传感器测距 mm → m
            # real[1:5] 为时间戳，不参与特征计算
            pdoa_raw = real[5]                  # 列105：PDOA原始寄存器值
            # real[6] = TDOA，此方法不使用
            p1   = real[7]                      # 列107：天线1信号功率（dBm）
            p2   = real[8]                      # 列108：天线2信号功率（dBm）
            fpp1 = real[9]                      # 列109：天线1首径功率
            fpp2 = real[10]                     # 列110：天线2首径功率
            dist_gt  = real[11]                 # 列111：距离真实值（m）
            angle_gt = real[12]                 # 列112：角度真实值（°）

            # ---------- 从CIR计算FPA和MA ----------
            fpa1 = compute_FPA(cir1)
            fpa2 = compute_FPA(cir2)
            ma1  = compute_MA(cir1)
            ma2  = compute_MA(cir2)

            # ---------- 计算6个输入特征 ----------
            f1 = compute_F1(pdoa_raw)
            f2 = compute_F2(p1, p2)
            f3 = compute_F3(fpa1, fpa2)
            f4 = compute_F4(fpp1, fpp2)
            f5 = compute_F5(fpa1, fpa2, ma1, ma2)
            f6 = compute_F6(cir1, cir2)

            X_list.append([f1, f2, f3, f4, f5, f6])
            y_angle_list.append(angle_gt)
            y_dist_list.append(dist_gt)
            dist_sensor_list.append(dist_sensor_m)

        except Exception:
            n_skip += 1
            continue

    if n_skip:
        print(f"  跳过 {n_skip} 行（解析失败）")

    return (
        np.array(X_list,           dtype=np.float32),
        np.array(y_angle_list,     dtype=np.float32),
        np.array(y_dist_list,      dtype=np.float32),
        np.array(dist_sensor_list, dtype=np.float32),
    )


# ============================================================
# 4.  鼠群优化器（RSO）—— 优化 SVR 超参数 C、ε、γ
# ============================================================

def rso_optimize_svr(X_train, y_train,
                     n_rats=5, max_iter=5,
                     search_bounds=None, cv=2, random_state=42):
    """
    使用鼠群优化器（RSO）在对数搜索空间内寻找最优SVR超参数。

    RSO 算法（论文公式15-17）：
    -------------------------------------------------------
    追逐猎物阶段：
        P       = A·Pi(x) + B·(Pr(x) - Pi(x))      (15)
        A       = R - x·(R/MaxIteration)             (16)
                  R ~ U[1, 5]，B ~ U[0, 2]
    更新位置：
        Pi(x+1) = |Pr(x) - P|                       (17)
    -------------------------------------------------------
    其中 Pi(x) 为第 i 只鼠在第 x 次迭代的位置（超参数向量），
    Pr(x) 为当前全局最优位置（"猎物"）。

    搜索空间（对数域，提升数值稳定性）：
        log10(C)   ∈ [-1, 3]   →   C       ∈ [0.1,   1000]
        log10(ε)   ∈ [-3, 0]   →   ε       ∈ [0.001,  1.0]
        log10(γ)   ∈ [-3, 0]   →   γ       ∈ [0.001,  1.0]

    适应度函数：k折交叉验证 RMSE（越小越好）。

    返回
    ----
    best_params : dict   最优超参数字典 {'C', 'epsilon', 'gamma'}
    """
    rng = np.random.default_rng(random_state)

    # 搜索边界矩阵，形状 (n_dim, 2)
    if search_bounds is None:
        search_bounds = np.array([
            [-1.0,  3.0],   # log10(C)
            [-3.0,  0.0],   # log10(ε)
            [-3.0,  0.0],   # log10(γ)
        ])
    lb, ub = search_bounds[:, 0], search_bounds[:, 1]
    n_dim = len(lb)

    def fitness(pos):
        """将对数域位置还原为超参数，计算交叉验证RMSE。"""
        C     = 10.0 ** pos[0]
        eps   = 10.0 ** pos[1]
        gamma = 10.0 ** pos[2]
        svr = SVR(kernel="rbf", C=C, epsilon=eps, gamma=gamma, cache_size=100)
        scores = cross_val_score(svr, X_train, y_train,
                                 cv=cv, scoring="neg_mean_squared_error")
        return float(np.sqrt(-scores.mean()))

    # ---------- 初始化：在搜索空间内随机均匀分布鼠群 ----------
    positions = rng.uniform(lb, ub, size=(n_rats, n_dim))
    fit_vals  = np.array([fitness(p) for p in positions])

    # 确定初始全局最优位置（猎物位置 Pr）
    best_idx = int(np.argmin(fit_vals))
    best_pos = positions[best_idx].copy()
    best_fit = fit_vals[best_idx]

    print(f"  RSO 初始最优 RMSE = {best_fit:.4f}°")

    # ---------- RSO 主迭代 ----------
    for x in range(1, max_iter + 1):
        R = rng.uniform(1.0, 5.0)                        # 公式(16)：R ~ U[1,5]
        A = R - x * (R / max_iter)                       # A 随迭代从 R 衰减至 0
        B = rng.uniform(0.0, 2.0, size=(n_rats, n_dim))  # B ~ U[0,2]，逐鼠独立采样

        for i in range(n_rats):
            # 公式(15)：计算中间向量 P
            P = A * positions[i] + B[i] * (best_pos - positions[i])
            # 公式(17)：新位置为猎物位置与 P 之差的绝对值
            new_pos = np.abs(best_pos - P)
            # 边界处理：超出搜索空间则截断
            new_pos = np.clip(new_pos, lb, ub)

            new_fit = fitness(new_pos)
            # 贪心更新：只有更优才替换
            if new_fit < fit_vals[i]:
                positions[i] = new_pos
                fit_vals[i]  = new_fit
                # 更新全局最优（猎物位置）
                if new_fit < best_fit:
                    best_pos = new_pos.copy()
                    best_fit = new_fit

        print(f"  RSO 迭代 {x:3d}/{max_iter}  当前最优 RMSE = {best_fit:.4f}°")

    # 将对数域最优位置还原为实际超参数
    best_params = {
        "C":       float(10.0 ** best_pos[0]),
        "epsilon": float(10.0 ** best_pos[1]),
        "gamma":   float(10.0 ** best_pos[2]),
    }
    print(f"  RSO 收敛：C={best_params['C']:.4f}  "
          f"ε={best_params['epsilon']:.6f}  "
          f"γ={best_params['gamma']:.6f}")
    return best_params


# ============================================================
# 5.  评估指标
# ============================================================

def evaluate(model, X, y_true, label=""):
    """计算并打印 MAE 和 RMSE（单位：°）。"""
    y_pred = model.predict(X)
    mae  = float(np.mean(np.abs(y_pred - y_true)))
    rmse = float(np.sqrt(np.mean((y_pred - y_true) ** 2)))
    print(f"  [{label:24s}]  MAE={mae:.4f}°   RMSE={rmse:.4f}°   N={len(y_true)}")
    return y_pred


# ============================================================
# 6.  主流程
# ============================================================

print("=" * 60)
print("RSO-SVR  —  UWB AOA 估计")
print("=" * 60)

# -----------------------------------------------------------
# 6-1.  加载同源主数据集（datasets-2d-azi.csv）
# -----------------------------------------------------------
print("\n[1]  加载主数据集 ...")
X_main, y_angle_main, y_dist_main, dist_sensor_main = load_dataset(
    "datasets/datasets-2d-azi.csv"
)
N = len(X_main)
print(f"  总样本数 : {N}")
print(f"  角度范围 : [{y_angle_main.min():.1f}°, {y_angle_main.max():.1f}°]")

# -----------------------------------------------------------
# 6-2.  划分训练集 / 验证集 / 测试集（70% / 15% / 15%）
# -----------------------------------------------------------
rng_split = np.random.default_rng(42)
perm = rng_split.permutation(N)

n_train = int(0.70 * N)
n_val   = int(0.15 * N)
n_test  = N - n_train - n_val

idx_train = perm[:n_train]
idx_val   = perm[n_train : n_train + n_val]
idx_test  = perm[n_train + n_val :]

X_train_raw,  y_train  = X_main[idx_train], y_angle_main[idx_train]
X_val_raw,    y_val    = X_main[idx_val],   y_angle_main[idx_val]
X_test_raw,   y_test   = X_main[idx_test],  y_angle_main[idx_test]
dist_label_test  = y_dist_main[idx_test]
dist_sensor_test = dist_sensor_main[idx_test]

print(f"  数据划分 : 训练={n_train}  验证={n_val}  测试={n_test}")

# -----------------------------------------------------------
# 6-3.  特征标准化（StandardScaler 只在训练集上 fit）
# -----------------------------------------------------------
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train_raw)
X_val   = scaler.transform(X_val_raw)
X_test  = scaler.transform(X_test_raw)

# -----------------------------------------------------------
# 6-4.  加载非同源测试集（datasets-3d-azi-out.csv）
# -----------------------------------------------------------
print("\n[2]  加载非同源测试集 ...")
X_out_raw, y_angle_out, y_dist_out, dist_sensor_out = load_dataset(
    "datasets/datasets-3d-azi-out.csv"
)
# 使用同源数据的 scaler 进行归一化（模拟实际部署场景）
X_out = scaler.transform(X_out_raw)
print(f"  样本数   : {len(X_out)}")
print(f"  角度范围 : [{y_angle_out.min():.1f}°, {y_angle_out.max():.1f}°]")

# -----------------------------------------------------------
# 6-5.  RSO 超参数优化（在训练集上进行，使用交叉验证评估适应度）
# -----------------------------------------------------------
print("\n[3]  RSO 超参数优化 ...")
best_params = rso_optimize_svr(
    X_train, y_train,
    n_rats=5,    # 鼠群数量
    max_iter=5,  # 最大迭代次数
    cv=2,         # 交叉验证折数
)

# -----------------------------------------------------------
# 6-6.  用最优超参数在完整训练集上训练最终 SVR
# -----------------------------------------------------------
print("\n[4]  训练最终 SVR ...")
svr = SVR(kernel="rbf", cache_size=1000, **best_params)
svr.fit(X_train, y_train)
print(f"  训练完成，支持向量数：{len(svr.support_vectors_)}")

# 保存模型和 scaler（推理时需要同一个 scaler 做归一化）
joblib.dump(svr,    "rso_svr_model.pkl")
joblib.dump(scaler, "rso_svr_scaler.pkl")
print("  模型已保存：rso_svr_model.pkl")
print("  Scaler 已保存：rso_svr_scaler.pkl")

# -----------------------------------------------------------
# 6-7.  模型评估
# -----------------------------------------------------------
print("\n[5]  模型评估 ...")
evaluate(svr, X_train, y_train,       "训练集（同源）")
evaluate(svr, X_val,   y_val,         "验证集（同源）")
y_pred_test = evaluate(svr, X_test,   y_test,       "测试集（同源）")
y_pred_out  = evaluate(svr, X_out,    y_angle_out,  "测试集（非同源）")

# -----------------------------------------------------------
# 6-8.  保存结果到 rso-svr.csv
# -----------------------------------------------------------
print("\n[6]  保存结果到 rso-svr.csv ...")

# 列顺序与其他脚本一致：
#   dist_sensor_m | dist_label_m | angle_pred_deg | angle_label_deg
rows = []

# 前段：同源测试集
for i in range(len(y_pred_test)):
    rows.append([
        float(dist_sensor_test[i]),
        float(dist_label_test[i]),
        float(y_pred_test[i]),
        float(y_test[i]),
    ])

# 后段：非同源测试集
for i in range(len(y_pred_out)):
    rows.append([
        float(dist_sensor_out[i]),
        float(y_dist_out[i]),
        float(y_pred_out[i]),
        float(y_angle_out[i]),
    ])

with open("rso-svr.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(rows)

print(f"  共保存 {len(rows)} 行  "
      f"（同源={len(y_pred_test)}，非同源={len(y_pred_out)}）")
print("  列顺序：dist_sensor_m, dist_label_m, angle_pred_deg, angle_label_deg")
print("\n完成。")
