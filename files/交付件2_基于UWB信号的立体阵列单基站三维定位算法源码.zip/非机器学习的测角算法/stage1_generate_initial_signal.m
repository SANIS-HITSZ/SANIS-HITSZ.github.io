%% 参数设置
dra=0;%if plot mudulate figure
c=3e8;
% num_user=3;
% num=31;
% fs=10e9;%采样率10Ghz
% Tc=100e-9;
% Tm=2e-9;
% pow=0;%dbm
% Nh=256;%一帧中码片个数
Ts=Nh*Tc;
frame_sample=round(Ts*fs);%一个frame采样数
chipsamples=round(Tc*fs);%一个chip采样数
pulse_sample=round(Tm*fs);
%Np=31;%TH码长
delta=Tm*2.5;
Tf=Tc*Nh;
alpha=Tm/3;
Tmin=-Tm/2;
Tmax=Tm/2;
t=Tmin:1/fs:Tmax;
power=(10^(pow/10))/1000;  %单位为w
Ex = power * Ts;%一帧时间的能量
pulse0=gaussians(t,pulse_message,alpha);%生成波形选择
Epulse=sum(pulse0.^2/fs);
pulse=pulse0/sqrt(Epulse)*sqrt(Ex);

% bits=bit(num); %发送序列信息
% bits(1)=0;
[THcode,Np] = GoldMultiuser(9,8);
num=size(THcode,2);
% THcode = TH(Nh,Np);
%% 发送数据初始化
%生成导频
SYN_mode;
SFD_mode;
length_syn=length(SYN_seq);
synsfd_pilot=[repmat(SYN_seq,1,SYN_PSR),SFD_seq,zeros(1,length_syn)];
%生成数据
bits=round(rand(1,num_user));
L=num*round(Tf*fs);
Stx=zeros(num_user,L);
for u_n=1:num_user
bit=repmat(bits(u_n),1,num);
[PPMseq,THseq] = PPM(bit,fs,Tc,Tf,delta,THcode(u_n,:),num);
Sa=conv(PPMseq,pulse);
Stx(u_n,:)=Sa(1:L);
end
%拼接
tx0=[synsfd_pilot,sum(Stx,1)];
%% 计算带宽
fre1=fftshift(fft(Stx(1,1:frame_sample)));
fplot=fs/length(Stx(1,1:frame_sample))*[-1*length(Stx(1,1:frame_sample))/2:length(Stx(1,1:frame_sample))/2-1];
band_sub=sqrt(sum(fplot.^2.*abs(fre1).^2)/sum((abs(fre1).^2)));
%% 绘图
tmax = num*Tf;
time = linspace(0,tmax,length(Stx));
if dra==1
    P =plot(time,sum(Stx,1));
    ylow=-8*abs(min(pulse));
    yhigh=8*max(pulse);
    axis([0 tmax ylow yhigh]);
    X=xlabel('Time [s]');
    Y=ylabel('Amplitude [V]');
    T=title('Modulation Signal Waveform');
    hold on
    for j=1:num
        tj=(j-1)*Tf;
        line([tj tj],[ylow yhigh],'Color',[0 0 0],'LineStyle','--','LineWidth',[1.5]);
        for q=1:Nh-1
            th =tj +q*Tc;
            line([th th],[0.8*ylow 0.8*yhigh],'Color',[0 0 0],'LineStyle',':','LineWidth',[1]);
        end
    end
end