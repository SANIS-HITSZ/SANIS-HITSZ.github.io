%% 接收端模板信号
%modelpulse0=[pulse,ones(1,chipsamples/2-length(pulse)),zeros(1,frame_sample-chipsamples/2)];
modelpulse0=[pulse,zeros(1,frame_sample-length(pulse))];
TemplateSig1=zeros(num_user,round(num*frame_sample));
TemplateSig2=zeros(num_user,round(num*frame_sample));
TemplateSig=zeros(num_user,round(num*frame_sample));
for temp = 1:num
    for nAgent = 1:num_user
        nTH = THcode(nAgent,1 + mod(temp-1,Np));     % TH码一个周期内的码元位置
        % 生成各条链路的模板信号
        TemplateSig1(nAgent,1+(temp-1)*frame_sample:temp*frame_sample) = [zeros(1,nTH*chipsamples),modelpulse0(1:end-nTH*chipsamples)];
        TemplateSig2(nAgent,1+(temp-1)*frame_sample:temp*frame_sample) = [zeros(1,nTH*chipsamples+round(delta*fs)),modelpulse0(1:end-nTH*chipsamples-round(delta*fs))];
        TemplateSig(nAgent,1+(temp-1)*frame_sample:temp*frame_sample) =  TemplateSig1(nAgent,1+(temp-1)*frame_sample:temp*frame_sample)-TemplateSig2(nAgent,1+(temp-1)*frame_sample:temp*frame_sample);
    end
end
%% 调回同步
Smark=zeros(1,num_user);
for ui=1:num_user
    Smark(ui)=Rmarker_rx(ui)-1;
end
%% 相关接收
rx_flag=zeros(num_user,1);
for nAgent = 1:num_user
    RXSumMask = [rx0(nAgent,Smark(nAgent)+length(synsfd_pilot)+1:end),zeros(1,frame_sample)];     %  当前链路调回同步
    xccorr =  RXSumMask(1:length(TemplateSig)).*TemplateSig(nAgent,:);                       % 接收端信号与本地模板信号做相关                                       % sig是发射的高斯脉冲
    xcMask = sum(xccorr);             % 计算相关掩模
    % PPM解调
    if xcMask > 0
        rx_flag(nAgent) = 0;
    else
        rx_flag(nAgent) = 1;
    end
    if rx_flag(nAgent)==bits(nAgent)
        str=num2str(nAgent);
        disp(['第',str,'号用户数据解调成功']);
    end
end

clearvars -except 'step1.mat' 'Rmarker_rx' 'synsfd_pilot' 'nstdv' 'h' 'noise_thred_pilot'...
    'ms' 'X' 'Y' 'Z' 'au_dis' 'L_add' 'fs' 'num_user' 'c' 'SFDSequence' 'SYN_PSR' 'length_syn'...
    'SYN_seq' 'pulse_syn' 'n00' 'noise_thred_pilot' 'Ex' 's_w' 'element_num' 't_syn' 't_rec'...
    't_delta' 'element_num' 'p_gap' 'aoalen' 'pulse_sample' 'pilot_gap' 'd_ele' 'mL' 'ttt' 'msL'...
    'rmse_cdf' 'jqk'