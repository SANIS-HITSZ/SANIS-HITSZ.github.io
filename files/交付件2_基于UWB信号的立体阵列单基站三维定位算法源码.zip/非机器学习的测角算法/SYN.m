% ���ݸ��������������ź������������
% modelpulse : ��������
% index : ���б��
% modelpulse_seq : �����������ɵ���������
function modelpulse_seq = SYN(modelpulse, index)

sequence_25 = [-1 0 1 1 1 1, -1 -1 1, -1 -1 1, -1 1 1 1 1, -1 1 -1, -1 -1 1 1 -1, -1 1, 1 1  1 1, 1 -1 1 1 -1, 1 0 0 1 -1, -1 1 0 -1,...
    -1 1 0, 1 1 1 1 1, -1 -1 1 , 1 1 -1, -1 0 -1, -1 0 1, -1 1 -1, -1 -1 -1, 0 -1 1,-1 1 -1, 1 0 1, -1 -1 1, 1 -1 1, -1 1 1 1 0];
sequence_26 = [1 1 0 1 -1 1 -1 -1 -1 1 1 1 1 1 -1 1 -1 1 1 -1 -1 1 -1 -1 1 1 -1 -1 -1 1 -1 0 1 1 1 0 -1 1 1 1 1 -1 1 0 1 0 -1 -1 0 1 -1 1 1 -1 1 1,...
    1 1 1 1 -1 -1 1 -1 1 1 0 0 1 1 1, -1 -1 0 1 -1 -1 -1 -1 -1 1 -1 0 1 -1 1 -1 1 -1 -1 -1];
sequence_27 = [ 1 1 1 -1 -1 1 1 1 -1 -1 -1 1 -1 1 -1 0 -1 1 -1 -1 0 1 1 -1 1 -1 1 0 -1 1 1 1  1 1 1 1 1 1 1 -1 -1 1 -1 -1 1 1 -1 1 1 0 1 1 -1 1 -1 1,...
    -1 -1 1 -1 -1 1 1 1 -1 -1 -1 0 -1 1 1 1  -1 0 1 0 0 -1 -1 -1 1 1 -1 1 -1 -1 0 -1 1 1 0];
sequence_28 = [ 1 1 1 1 1 -1 -1 1 1 1 -1 1 1 -1 -1 -1 1  -1 1 -1 -1 0 1 1 -1 -1 -1 1 -1 1 0 1 -1 -1 -1 -1 -1 1 0 1  1 1 -1 -1 1 -1 1 -1 -1 1 -1 1 1 -1 1 1,...
 1 1 0 -1 0 -1 1 1 0 0 1 -1 1 1 1 -1 1  1 -1 1 0 -1 1 0 -1 -1 1 -1 -1 -1 1 1 1 0 1];
sequence_29 = [ 1 -1 0 -1 -1 1 -1 1 1 -1 -1 0 1 1 0 0 1 1 -1  1 1 -1 -1 -1 -1 -1 1 1 1 1 1 1 -1 0 1  -1 -1 1 -1 1 1 -1 -1 1 -1 1 1 1 -1 -1 1 1 1 1 1 1,...
 1 -1 1 1 1 0 1 -1 1 -1 0 -1 0 -1 1 1 -1 -1 -1 1 0 -1 -1 -1 1 1 0 -1 1 -1 1 -1 1 1 -1];
sequence_30 = [ -1 1 1 0 -1 -1 0 1 1 -1 0 0 -1 -1 1 1 -1 1 1 -1 1  -1 -1 1 1 1 1 1 -1 -1 -1 1 1 1 -1 1 -1 0 1 -1  1 -1 1 0 1 1 1 1 1 -1 1 1 1 -1 1 1,...
 1 -1 1 0 -1 -1 -1 -1 -1 -1 1 1 -1 1 1 -1 1 0 -1 -1 -1 -1 1  -1 1 -1 0 1 0 1 -1 1 1 1 -1];
sequence_31 = [ -1 1 -1 1 1 0 1 1 1 -1 -1 1 1 -1 0 1  1 0 0 -1 -1 1 1 -1 -1 1 1 1 -1 1 -1 -1 -1 -1 -1 -1 0 1  1 1 -1 1 1 1 1 1 -1 -1 1 -1 1 1 -1 -1 -1 1,...
 -1 1 -1 -1 -1 1 -1 1 0 -1 1 -1 -1 0 1 0 1 -1 1  1 -1 1 1 0 1 -1 1 -1 -1 0 1 1 1 1 1];
sequence_32 = [ -1 1 1 1 1 1 1 1 1 1 1 1 -1 -1 -1 1 -1 1 1  -1 -1 1 1 0 0 -1 1 -1 1 0 -1 1 -1 0 -1 1 1 -1 -1 1 1 1 -1 1 1 1 0 -1 -1 0 1 1 -1 1 -1 1,...
 -1 0 -1 -1 -1 1 1 -1 0 -1 -1 -1 -1 1 1 1 1 -1 1 -1 0 1 0 -1 1 -1 1 1 -1 1 1 -1 -1 1 -1];

% for test
% sequence_25 = [1 0 1 -1];

zero_num = 3;
len_seq = length(sequence_25);
emp = zeros(zero_num,len_seq);
len_pulse = length(modelpulse);
switch index
    case 25 
        % ����3��0��
        sequence_full = reshape([sequence_25;emp],1,(zero_num+1)*len_seq);
    case 26
        % ����3��0��
        sequence_full = reshape([sequence_26;emp],1,(zero_num+1)*len_seq);
    case 27
        % ����3��0��
        sequence_full = reshape([sequence_27;emp],1,(zero_num+1)*len_seq);
    case 28
        % ����3��0��
        sequence_full = reshape([sequence_28;emp],1,(zero_num+1)*len_seq);
    case 29
        % ����3��0��
        sequence_full = reshape([sequence_29;emp],1,(zero_num+1)*len_seq);
    case 30 
        % ����3��0��
        sequence_full = reshape([sequence_30;emp],1,(zero_num+1)*len_seq);
    case 31
        % ����3��0��
        sequence_full = reshape([sequence_31;emp],1,(zero_num+1)*len_seq);
    case 32
        % ����3��0��
        sequence_full = reshape([sequence_32;emp],1,(zero_num+1)*len_seq);
    otherwise
        disp('��Ŵ���');
end
        % ������������ĳ����Լ�����������������
        sequence_for_multi = repmat(sequence_full,len_pulse,1);
        modelpulse_seq = reshape(sequence_for_multi,1,(zero_num+1)*len_seq*len_pulse).*repmat(modelpulse,1,(zero_num+1)*len_seq);  
end
