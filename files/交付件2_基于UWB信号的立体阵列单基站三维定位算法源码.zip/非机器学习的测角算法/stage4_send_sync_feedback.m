%% 传输时钟漂移矫正信息
gap1=t_syn*fs;%
tx0=[zeros(1,gap1),synsfd_pilot];
befm=max(abs(tx0));
Stx1=conv(tx0,h(1:1000));
Stx1=Stx1(2:length(tx0)+1);
aftm=max(abs(Stx1));
Stx1=Stx1*befm/aftm;
rx0=zeros(num_user,length(tx0)+L_add);
for ui=1:num_user
    tx1=Stx1+nstdv*randn(1,length(tx0));
    rx0(ui,:)=[zeros(1,round(au_dis(ui)/c*fs)),tx1,zeros(1,L_add-round(au_dis(ui)/c*fs))];
end
%% 
length_rxn=size(rx0,2);
indexCap=zeros(num_user,length(SFDSequence)+SYN_PSR);
rx1=zeros(num_user,length_rxn-length_syn+1);
for tx = 1:num_user   
    f=waitbar(0,['user',num2str(tx),' 开始捕获同步信息pilot...']);
    rx1(tx,:)=conv(rx0(tx,:),flip(SYN_seq),'valid');
    numCap = 0;
    flagii=1;
    length_rx1=length_rxn-length_syn+1;
    while flagii<length_rx1
        if abs(rx1(tx,flagii))>noise_thred_pilot
            [~,flag]=max(abs(rx1(tx,flagii:flagii+5)));
            numCap=numCap+1;
            indexCap(tx,numCap)=flagii+flag-1;
            flagii=flagii+0.8*length(SYN_seq);
            str=['user',num2str(tx),': 同步信息pilot捕获进度...'];
            waitbar(numCap/(length(SFDSequence)+SYN_PSR),f,str);
        else
            flagii=flagii+1;
        end
        if numCap==length(SFDSequence)+SYN_PSR
            break
        end
        if flagii>=length_rx1
            str=num2str(tx);
            disp(['第',str,'号用户pilot捕获失败']);
        end
    end
    close(f)
end
Rmarker_rx2=indexCap(:,1);