%% user端 用户数量少
rec_index=Rmarker_rx2-gap1;%用户接收到同步信息的序列位置
rec_gap=t_rec*fs;%固定回复间隔
delta_gap=t_delta*fs;%每个用户回复间隔差
L_rec=rec_gap+delta_gap*num_user;
load('pilot_aoa');
pilot_aoa=pilot_aoa*sqrt(Ex);
retx0=zeros(num_user,L_rec+length(synsfd_pilot)+max(rec_index)+length(pilot_aoa));
for ru=1:num_user
    retx0(ru,rec_gap+rec_index(ru)+ru*delta_gap:rec_gap+rec_index(ru)+ru*delta_gap+length(synsfd_pilot)+length(pilot_aoa)-1)=[synsfd_pilot,pilot_aoa];
end
retxh=zeros(num_user,size(retx0,2)+L_add);
for ru=1:num_user
%     f=waitbar(0,['基站接收','user',num2str(ru),' 的回传信息...']);
    befm=max(abs(retx0(ru,:)));
    Stx1=conv(retx0(ru,:),h(1:1000));
    Stx1=Stx1(2:length(retx0(ru,:))+1);
    aftm=max(abs(Stx1));
    Stx1=Stx1*befm/aftm;
    retxh(ru,:)=[zeros(1,round(au_dis(ru)/c*fs)),Stx1,zeros(1,L_add-round(au_dis(ru)/c*fs))];
%                 str=['基站捕获','user',num2str(tx),' 的pilot捕获进度...'];
%             waitbar(numCap/(length(SFDSequence)+SYN_PSR),f,str);
end

%% agent端
% element_num=8;%number of element 
rerx0=sum(retxh,1)+nstdv*randn(2*element_num-1,size(retxh,2));%15个阵元的接收信号
length_rerx=size(rerx0,2);
indexCap=zeros(num_user,length(SFDSequence)+SYN_PSR);
dr=0.1;%大于 回发数据长度 与 回复间隔差的比值
rerx0=[rerx0,zeros(2*element_num-1,rec_gap+(num_user+dr)*delta_gap-length_rerx)];
rerx1=zeros(num_user,dr*delta_gap-length(SYN_seq)+1);
for tx = 1:num_user  
    rerx1(tx,:)=conv(rerx0(1,rec_gap+tx*delta_gap+1:rec_gap+(tx+dr)*delta_gap),flip(SYN_seq),'valid');
    numCap = 0;
    flagii=1;
    length_rx1=length_rxn-length_syn+1;
    while flagii<length_rx1
        if abs(rerx1(tx,flagii))>noise_thred_pilot
            [~,flag]=max(abs(rerx1(tx,flagii:flagii+5)));%保护间隔
            numCap=numCap+1;
            indexCap(tx,numCap)=rec_gap+tx*delta_gap+flagii+flag-1;
            flagii=flagii+0.8*length(SYN_seq);
        else
            flagii=flagii+1;
        end
        if numCap==length(SFDSequence)+SYN_PSR
            break
        end
        if flagii>=length_rx1
            str=num2str(tx);
            disp(['第',str,'号用户pilot捕获失败']);
        end
    end
end
Rmarker_rx3=indexCap(:,1);


clearvars -except 'step1.mat' 'Rmarker_rx' 'synsfd_pilot' 'nstdv' 'h' 'noise_thred_pilot'...
    'ms' 'X' 'Y' 'Z' 'au_dis' 'L_add' 'fs' 'num_user' 'c' 'SFDSequence' 'SYN_PSR' 'length_syn'...
    'SYN_seq' 'pulse_syn' 'n00' 'noise_thred_pilot' 'Ex' 'rerx0' 'Rmarker_rx3' 'Rmarker_rx2'...
    'element_num' 'rec_gap' 'delta_gap' 's_w' 'element_num' 'p_gap' 'aoalen' 'pulse_sample' ...
    'pilot_gap' 'd_ele' 'mL' 'ttt' 'msL' 'rmse_cdf' 'jqk'