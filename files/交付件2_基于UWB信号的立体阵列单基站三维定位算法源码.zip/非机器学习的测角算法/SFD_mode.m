%% 
SFDSequence=SFD(SFD_index);
length_sfd=length(SFDSequence);
temp_sfd=kron(SYN_seq,SFDSequence);
temp_sfd=reshape(temp_sfd,length_sfd,[]);
SFD_seq=reshape(temp_sfd',1,[]);