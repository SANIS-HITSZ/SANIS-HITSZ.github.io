%% user端 用户数量多
cyc_num=floor(num_user/4);%每个mat存4个user的信息
rec_index=Rmarker_rx2-gap1;%用户接收到同步信息的序列位置
rec_gap=t_rec*fs;%固定回复间隔
delta_gap=t_delta*fs;%每个用户回复间隔差
L1=rec_gap+delta_gap*5;
L2=delta_gap*4;
load('pilot_aoa');
pilot_aoa=pilot_aoa*sqrt(Ex);
f=waitbar(0,'用户正在回传信息...');
for re=1:cyc_num   
    if re==1
        retx0=zeros(4,rec_gap+delta_gap*5);
        for ru=1:4
            retx0(ru,rec_gap+rec_index(ru)+ru*delta_gap:rec_gap+rec_index(ru)+ru*delta_gap+length(synsfd_pilot)+length(pilot_aoa)-1)=[synsfd_pilot,pilot_aoa];
        end
    else
        retx0=zeros(4,delta_gap*4);
        for ru=1:4
            retx0(ru,rec_index((re-1)*4+ru)+(ru-1)*delta_gap:rec_index((re-1)*4+ru)+(ru-1)*delta_gap+length(synsfd_pilot)+length(pilot_aoa)-1)=[synsfd_pilot,pilot_aoa];
        end
    end
    retxh=zeros(4,size(retx0,2));
    for ru=1:4
        befm=max(abs(retx0(ru,:)));
        Stx1=conv(retx0(ru,:),h(1:1000));
        Stx1=Stx1(2:length(retx0(ru,:))+1);
        aftm=max(abs(Stx1));
        Stx1=Stx1*befm/aftm;
        temp=[zeros(1,round(au_dis((re-1)*4+ru)/c*fs)),Stx1];
        retxh(ru,:)=temp(1:end-round(au_dis((re-1)*4+ru)/c*fs));    
    end
    str=['第',num2str(re),' 组用户正回传信息...'];
    waitbar(re/cyc_num,f,str);
    retxh=sum(retxh,1);
    str=['g',num2str(re),'.mat'];
    save(str,'retxh');
end
close(f);
retx0=zeros(num_user-cyc_num*4,delta_gap*(num_user-cyc_num*4));
retxh=zeros(num_user-cyc_num*4,size(retx0,2));
for re=(cyc_num*4+1):num_user
    retx0(re-cyc_num*4,rec_index(re)+(re-cyc_num*4-1)*delta_gap:rec_index(re)+(re-cyc_num*4-1)*delta_gap+length(synsfd_pilot)+length(pilot_aoa)-1)=[synsfd_pilot,pilot_aoa];
    befm=max(abs(retx0(re-cyc_num*4,:)));
    Stx1=conv(retx0(re-cyc_num*4,:),h(1:1000));
    Stx1=Stx1(2:size(retx0,2)+1);
    aftm=max(abs(Stx1));
    Stx1=Stx1*befm/aftm;
    temp=[zeros(1,round(au_dis(re)/c*fs)),Stx1];
    retxh(re-cyc_num*4,:)=temp(1:end-round(au_dis(re)/c*fs));
    if re==num_user
        retxh=sum(retxh,1);
        str=['g',num2str(cyc_num+1),'.mat'];
        save(str,'retxh');
    end
end
%% agent端
indexCap=zeros(num_user,length(SFDSequence)+SYN_PSR);
dr=0.1;
f=waitbar(0,'基站正在接收用户的回传信息...');
for re=1:cyc_num
    str=['g',num2str(re),'.mat'];
    load(str);
    % element_num=8;%number of element
    rerx0=retxh+nstdv*randn(2*element_num-1,size(retxh,2));%15个阵元的接收信号
    rerx1=zeros(4,dr*delta_gap-length(SYN_seq)+1);
    for ru=1:4
        if re==1
            rerx1(ru,:)=conv(rerx0(1,rec_gap+ru*delta_gap+1:rec_gap+(ru+dr)*delta_gap),flip(SYN_seq),'valid');
        else
            rerx1(ru,:)=conv(rerx0(1,(ru-1)*delta_gap+1:round((ru+dr-1)*delta_gap)),flip(SYN_seq),'valid');
        end
        numCap = 0;
        flagii=1;
        length_rx1=dr*delta_gap-length(SYN_seq)+1;
        while flagii<length_rx1
            if abs(rerx1(ru,flagii))>noise_thred_pilot
                [~,flag]=max(abs(rerx1(ru,flagii:flagii+5)));%保护间隔
                numCap=numCap+1;
                indexCap(((re-1)*4+ru),numCap)=rec_gap+((re-1)*4+ru)*delta_gap+flagii+flag-1;
                flagii=flagii+0.8*length(SYN_seq);
            else
                flagii=flagii+1;
            end
            if numCap==length(SFDSequence)+SYN_PSR
                break
            end
            if flagii>=length_rx1
                str=num2str((re-1)*4+ru);
                disp(['基站端：用户',str,' pilot捕获失败']);
            end
        end
        output1=rerx0(:,indexCap((re-1)*4+ru,1)-(re>1)*L1-(re>2)*L2*(re-2)+length(synsfd_pilot)-p_gap:indexCap((re-1)*4+ru,1)-(re>1)*L1-(re>2)*L2*(re-2)+length(synsfd_pilot)+length(pilot_aoa)-1);
        str=['u',num2str((re-1)*4+ru),'.mat'];
        save(str,'output1');
    end
    str=['基站正在接收第',num2str(re),' 组用户的回传信息...'];
    waitbar(re/cyc_num,f,str);
end
close(f);

if ceil(num_user/4)>cyc_num
    str=['g',num2str(cyc_num+1),'.mat'];
    load(str);
    rerx0=retxh+nstdv*randn(2*element_num-1,size(retxh,2));%15个阵元的接收信号
    rerx1=zeros(num_user-cyc_num*4,dr*delta_gap-length(SYN_seq)+1);
    for ru=1:(num_user-cyc_num*4)
        rerx1(ru,:)=conv(rerx0(1,round((ru-1)*delta_gap+1):round((ru+dr-1)*delta_gap)),flip(SYN_seq),'valid');
        numCap = 0;
        flagii=1;
        length_rx1=dr*delta_gap-length(SYN_seq)+1;
        while flagii<length_rx1
            if abs(rerx1(ru,flagii))>noise_thred_pilot
                [~,flag]=max(abs(rerx1(ru,flagii:flagii+5)));%保护间隔
                numCap=numCap+1;
                indexCap((cyc_num*4+ru),numCap)=rec_gap+(cyc_num*4+ru)*delta_gap+flagii+flag-1;
                flagii=flagii+0.8*length(SYN_seq);
            else
                flagii=flagii+1;
            end
            if numCap==length(SFDSequence)+SYN_PSR
                break
            end
            if flagii>=length_rx1
                str=num2str(cyc_num*4+ru);
                disp(['基站端：用户',str,' pilot捕获失败']);
            end
        end
        output1=rerx0(:,indexCap(cyc_num*4+ru,1)-(cyc_num>0)*L1-(cyc_num>1)*L2*(cyc_num-1)+length(synsfd_pilot)-p_gap:indexCap(cyc_num*4+ru,1)-(cyc_num>0)*L1-(cyc_num>1)*L2*(cyc_num-1)+length(synsfd_pilot)+length(pilot_aoa)-1);
        str=['u',num2str(cyc_num*4+ru),'.mat'];
        save(str,'output1');
    end  
end
Rmarker_rx3=indexCap(:,1);


clearvars -except 'step1.mat' 'Rmarker_rx' 'synsfd_pilot' 'nstdv' 'h' 'noise_thred_pilot'...
    'ms' 'X' 'Y' 'Z' 'au_dis' 'L_add' 'fs' 'num_user' 'c' 'SFDSequence' 'SYN_PSR' 'length_syn'...
    'SYN_seq' 'pulse_syn' 'n00' 'noise_thred_pilot' 'Ex' 'Rmarker_rx3' 'Rmarker_rx2'...
    'element_num' 'rec_gap' 'delta_gap' 's_w' 'element_num' 'p_gap' 'aoalen' 'pulse_sample' ...
    'pilot_gap' 'd_ele' 'mL' 'ttt' 'msL' 'rmse_cdf' 'jqk'