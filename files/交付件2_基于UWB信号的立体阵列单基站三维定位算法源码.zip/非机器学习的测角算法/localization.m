%% ��λ
deltax=zeros(num_user,1);
juli=zeros(num_user,1);
MSp=zeros(num_user,3);
%MSpp=zeros(num_user,3);
%anglea_end(anglea_end<0)=anglea_end(anglea_end<0)+pi;
for twrid=1:num_user
    deltax(twrid)=Rmarker_rx3(twrid)-1-rec_gap-delta_gap*twrid;
    juli(twrid)=deltax(twrid)*c/fs/2;
    MSp(twrid,1)=juli(twrid)*sqrt(1-sin(anglee_end(twrid))^2-sin(anglea_end(twrid))^2);
    MSp(twrid,2)=juli(twrid)*sin(anglea_end(twrid));
    MSp(twrid,3)=juli(twrid)*sin(anglee_end(twrid));
end
% MSp_ave=mean(MSp,1);
% wuchaguoda=0;
% for i=1:num
%     if norm(MSp(i,:)-MSp_ave)>1
%         wuchaguoda=wuchaguoda+1;
%         MSpp(i,:)=[0 0 0];
%     else
%         MSpp(i,:)=MSp(i,:);
%     end
% end

% MSS=sum(MSpp,1);
% if norm(MSS)==0
%     [k_kluster,k_c]=kmeans(MSp,2);  % kmeans�����㷨
%     if length(find(k_kluster==1))>500
%         MS=k_c(1,:);
%     else
%         MS=k_c(2,:);
%     end
% else
%     MS=MSS/(num-wuchaguoda);
% end
MS=MSp;
for twrid=1:num_user
    RMSE = norm(MS(twrid,:)-ms(twrid,:));
    str_rmse=['user',num2str(twrid),': err = ',num2str(RMSE),' m'];
    disp(str_rmse);
end
%% 3-d fig
figure(1)
scatter3(X,Y,Z,200,'filled','r','p')
title('X-Y-Z fig')
xlabel('X axis [m]')
ylabel('Y axis [m]')
zlabel('Z axis [m]')
axis([0 50 0 5 0 5])
box on
grid on
hold on
stem3(ms(:,1),ms(:,2),ms(:,3),'filled','bh','MarkerSize',10)
stem3(MS(:,1),MS(:,2),MS(:,3),'filled','kp','MarkerSize',8)
hold off

%% 2-d fig
% figure(2)
% subplot(1,2,1)
% scatter(X,Y,200,'filled','r','p')
% title('X-Y fig')
% xlabel('X axis [m]')
% ylabel('Y axis [m]')
% axis([-2 50 -5 5])
% box on
% grid on
% hold on
% scatter(ms(:,1),ms(:,2),200,'filled','black','h')
% scatter(MS(:,1),MS(:,2),100,'filled','b','>')
% hold off
% 
% subplot(1,2,2)
% scatter(X,Z,200,'filled','r','p')
% title('X-Z fig')
% xlabel('X axis [m]')
% ylabel('Z axis [m]')
% axis([-2 50 0 5])
% box on
% grid on
% hold on
% scatter(ms(:,1),ms(:,3),200,'filled','black','h')
% scatter(MS(:,1),MS(:,3),100,'filled','b','>')
% hold off
% % anglea=atan((MS(2)-Y(1))/(MS(1)-X(1)));