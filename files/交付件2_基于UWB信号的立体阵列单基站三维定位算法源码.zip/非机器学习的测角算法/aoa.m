
%% ��ȡaoa�ź�\
% p_gap=1000;%�������
load('pilot_aoa.mat');
% aoalen=8;
% pulse_sample=20;
% pilot_gap=1000;
output1=zeros(2*element_num-1,length(pilot_aoa)+p_gap);
anglee_end=zeros(1,num_user);
anglea_end=zeros(1,num_user);
aoa_dua=length(pilot_aoa)/aoalen;
for ur=1:num_user
    output1=rerx0(:,Rmarker_rx3(ur)+length(synsfd_pilot)-p_gap:Rmarker_rx3(ur)+length(synsfd_pilot)+length(pilot_aoa)-1);
    % d_ele=0.1;%element distance
    buhuoshibai_flag=0;
    theta0=atan((ms(ur,2)-Y(1))/(norm([ms(ur,3)-Z(1),ms(ur,1)-X(1)])));%azimuth angle
    phai0=atan((ms(ur,3)-Z(1))/(norm([ms(ur,2)-Y(1),ms(ur,1)-X(1)])));%elevation angle
    theta=linspace(0,pi*0.494,90);
    phai=linspace(0,pi*0.494,90);
    angle_a=zeros(1,aoalen);
    angle_e=zeros(1,aoalen);
    dic=0;
    kk=0;
    output2=[zeros(2*element_num-1,p_gap),output1];
    capture_index=zeros(1,aoalen);
    f=waitbar(0,['user',num2str(ur),': AOA��ʼ��������...']);
    for aoa_flag=1:aoalen
        str=['user',num2str(ur),': AOA��һ�ε���������...'];
        waitbar(aoa_flag/aoalen*2,f,str);
        [~,dic_0]=max(output2(element_num,1.5*p_gap+aoa_dua*(aoa_flag-1)+1:1.5*p_gap+aoa_dua*aoa_flag+1));
        dic=dic_0+1.5*p_gap+aoa_dua*(aoa_flag-1);
        kk=kk+1;
        p2=zeros(length(phai),element_num,pulse_sample);
        ps2=zeros(length(phai),element_num);
        s2=zeros(length(phai),1);
        index2=round(d_ele*sin(phai0)/c*fs*[0:element_num-1]');
        for kkk=1:length(phai)
            index4=round(d_ele*sin(phai(kkk))/c*fs*[0:element_num-1]');
            for k=1:element_num
                for n=1:pulse_sample
                    p2(kkk,k,n)=output2(k+element_num-1,index4(k)-index2(k)+dic-floor(pulse_sample/2)+n-1);
                end
            end
            ps2=sum(p2,2);
            s2(kkk)=sum(ps2(kkk,:).^2);
        end
        %����1
        x=find(s2==max(s2));
        xx=x(ceil(length(x)/2));
        angle_e_temp1=phai(xx);
        angle_e(kk)=angle_e_temp1;
        capture_index(kk)=dic;
        if kk==aoalen
            break
        end
    end
    if kk~=aoalen %�������ʧ�ܲ�����ڶ��ε���
        buhuoshibai_flag=buhuoshibai_flag+1;
        err_a=0;
        err_e=0;
        anglea=0;
        anglee=0;
    else
        anglee = sum(angle_e)/kk;
        %err_e0=(phai0-anglee)*180/pi;
        
        %%�ڶ��ε���
        phai=linspace(anglee-pi/40,anglee+pi/40,90);
        for cap_index=1:aoalen
            str=['user',num2str(ur),': AOA��һ�ε���������...'];
            waitbar(cap_index+aoalen/aoalen*2,f,str);
            dic=capture_index(cap_index);
            p2=zeros(length(phai),element_num,pulse_sample);
            ps2=zeros(length(phai),element_num);
            s2=zeros(length(phai),1);
            for kkk=1:length(phai)
                index4=round(d_ele*sin(phai(kkk))/c*fs*[0:element_num-1]');
                for k=1:element_num
                    for n=1:pulse_sample
                        p2(kkk,k,n)=output2(k+element_num-1,index4(k)-index2(k)+dic-floor(pulse_sample/2)+n);
                    end
                end
                ps2=sum(p2,2);
                s2(kkk)=sum(ps2(kkk,:).^2);
            end
            
            x=find(s2==max(s2));
            xx=x(ceil(length(x)/2));
            angle_e(cap_index)=phai(xx);
        end
        anglee = sum(angle_e)/aoalen;
        err_e=(phai0-anglee)*180/pi;
        
        %��ˮƽ��
        for aoa_flag=1:aoalen
            str=['user',num2str(ur),': AOA�ڶ��ε���������...'];
            waitbar(aoa_flag/aoalen*2,f,str);
            dic=capture_index(aoa_flag);
            p=zeros(length(theta),element_num,pulse_sample);
            ps=zeros(length(theta),element_num);
            s=zeros(length(theta),1);
            index1=round(d_ele*sin(theta0)/c*fs*[0:element_num-1]');
            %index2=round(d_ele*sin(phai0)/c*fs*[0:element_num-1]');
            for jj=1:length(theta)
                index3=round(d_ele*sin(theta(jj))/c*fs*[0:element_num-1]');
                for k=1:element_num
                    for n=1:pulse_sample
                        p(jj,k,n)=output2(k,index3(k)-index1(k)+dic-floor(pulse_sample/2)+n-1);
                    end
                end
                ps=sum(p,2);
                s(jj)=sum(ps(jj,:).^2);
            end
            %����1
            x=find(s==max(s));
            xx=x(ceil(length(x)/2));
            angle_a_temp1=theta(xx);
            angle_a(aoa_flag)=angle_a_temp1;
        end
        
        anglea = sum(angle_a)/aoalen;
        %err_a0=(theta0-anglea)*180/pi;
        
        %%�ڶ��ε���
        theta=linspace(anglea-pi/40,anglea+pi/40,90);
        for cap_index=1:aoalen
            str=['user',num2str(ur),': AOA�ڶ��ε���������...'];
            waitbar(cap_index+aoalen/aoalen*2,f,str);
            dic=capture_index(cap_index);
            p=zeros(length(theta),element_num,pulse_sample);
            ps=zeros(length(theta),element_num);
            s=zeros(length(theta),1);
            for jj=1:length(theta)
                index3=round(d_ele*sin(theta(jj))/c*fs*[0:element_num-1]');
                for k=1:element_num
                    for n=1:pulse_sample
                        p(jj,k,n)=output2(k,index3(k)-index1(k)+dic-floor(pulse_sample/2)+n);
                    end
                end
                ps=sum(p,2);
                s(jj)=sum(ps(jj,:).^2);
            end
            x=find(s==max(s));
            xx=x(ceil(length(x)/2));
            angle_a(cap_index)=theta(xx);
        end
        anglea = sum(angle_a)/aoalen;
        err_a=(theta0-anglea)*180/pi;
    end
    str_erra=['user',num2str(ur),': err_azimuth = ',num2str(err_a),' degree'];
    disp(str_erra);
    str_erre=['user',num2str(ur),': err_elevation = ',num2str(err_e),' degree'];
    disp(str_erre);
    close(f);
    anglea_end(ur)=anglea;
    anglee_end(ur)=anglee;
end
%output2=output2(:,p_gap+1:end);

clearvars -except 'step1.mat' 'Rmarker_rx' 'synsfd_pilot' 'nstdv' 'h' 'noise_thred_pilot'...
    'ms' 'X' 'Y' 'Z' 'au_dis' 'L_add' 'fs' 'num_user' 'c' 'SFDSequence' 'SYN_PSR' 'length_syn'...
    'SYN_seq' 'pulse_syn' 'n00' 'noise_thred_pilot' 'Ex' 'rerx0' 'Rmarker_rx3' 'Rmarker_rx2'...
    'element_num' 'rec_gap' 'delta_gap'  'anglea_end' 'anglee_end' 's_w'  'mL' 'ttt' 'msL'...
    'rmse_cdf' 'jqk'