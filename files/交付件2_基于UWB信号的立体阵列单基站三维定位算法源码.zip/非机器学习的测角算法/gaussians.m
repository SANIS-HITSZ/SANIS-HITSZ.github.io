function [pulse] = gaussians(t,k,alpha)
switch(k)
    case 0
        pulse = -1*exp(-2*pi*(t/alpha).^2);
    case 1
        pulse = 4*pi*t/alpha^2.*exp(-2*pi*t.^2/alpha^2);
    case 2
        pulse = -4*pi*exp(-2*pi*(t.^2)/alpha^2).*(-alpha^2+4*pi*(t.^2))/alpha^4;
    case 3
        pulse = 16*pi^2*t.*exp(-2*pi*(t.^2)/alpha^2).*(-3*alpha^2+4*pi*(t.^2))/alpha^6;
    case 4
        pulse = -16*pi^2*exp(-2*pi*(t.^2)/alpha^2).*(3*alpha^4-24*pi*(t.^2)*alpha^2+16*pi^2*(t.^4))/alpha^8;
end
pulse= pulse/max(abs(pulse));
end

