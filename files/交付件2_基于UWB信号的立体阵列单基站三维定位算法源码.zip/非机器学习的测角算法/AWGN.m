function [output,noise,nstdv] = AWGN(Srx,ebn0,num,fs,bs)
Eb = (1/num)*sum(Srx.^2)/fs;
EbN0 = 10.^(ebn0./10); 
N0 = Eb ./ EbN0*bs ; 
nstdv = sqrt(N0/2);
for j = 1 : length(EbN0)        
    noise(j,:) = nstdv(j) .* randn(1,length(Srx));
    output(j,:) = noise(j,:) + Srx;    
end
end