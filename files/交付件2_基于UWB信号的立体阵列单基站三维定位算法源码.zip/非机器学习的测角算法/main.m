
%% 
clear
clc
close all
%% kalman
%mL=zeros(100,3);
%msL=zeros(100,3);
%for ttt=1:100
%% 网络环境设置
preset;

%% 发送波形
s_w=waitbar(1/8,'总进度：发送初始信息');
stage1_generate_initial_signal;

%% 信道仿真
waitbar(2/8,s_w,'总进度：信号广播发送');
stage2_simulate_channel_response;

%% 接收端
s_w=waitbar(3/8,s_w,'总进度：用户端捕获信息');
rec_syn;
s_w=waitbar(4/8,s_w,'总进度：用户端信息提取');
stage3_decode_user_data; %有clear

%% 同步信息发送以及用户接收
s_w=waitbar(5/8,s_w,'总进度：发送同步信息');
stage4_send_sync_feedback;

%% 回发信息
s_w=waitbar(6/8,s_w,'总进度：用户回发信息');
if num_user<5
    stage5_collect_small_user_reply;%有 clear
else
    stage6_collect_large_user_reply;%有 clear
end

%% 测角
s_w=waitbar(7/8,s_w,'总进度：基站进行AOA');
if num_user<5
    aoa;%有 clear
else
    aoa_large;    %有 clear
end
%% 定位
s_w=waitbar(8/8,s_w,'总进度：基站端进行定位');
localization;
close(s_w)



