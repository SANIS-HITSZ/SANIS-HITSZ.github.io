%% 位置设置
%ms=[31.5,3.5,1.85];
ms=[50*rand(num_user,1),5*rand(num_user,1),5*rand(num_user,1)];
%ms=[20,3,1.5]+[0.35,0.1,0.01]*ttt+[0.1,0.02,0.002]*randn;
% X=0;
% Y=0;
% Z=0;
au_dis=sqrt((ms(:,1)-X).^2+(ms(:,2)-Y).^2+(ms(:,3)-Z).^2);%agent—anchor 距离
alllen=size(tx0,2);
L_add=round(max(au_dis)/c*fs);
rx0=zeros(num_user,alllen+L_add);%经过信道后的接收信号 初始化
h=uwb4a_channel(3,12);%生成确定信道
%h=uwb4a_channel(round(sum(100*clock))); %生成随机信道
rand('state',sum(100*clock));
randn('state',sum(100*clock));
% ebn0=18;
h=abs(h)';
if length(h)<1000
    h=[h,zeros(1,1000-length(h))];
end
befm=max(abs(tx0));
Stx1=conv(tx0,h(1:1000));
Stx1=Stx1(2:alllen+1);
aftm=max(abs(Stx1));
Stx1=Stx1*befm/aftm;
for ui=1:num_user
[~,noise,nstdv] = AWGN([zeros(1,length(synsfd_pilot)),Stx(1,:)],ebn0,num,fs,band_sub);%%信道
tx1=Stx1+noise;
rx0(ui,:)=[zeros(1,round(au_dis(ui)/c*fs)),tx1,zeros(1,L_add-round(au_dis(ui)/c*fs))];
end
%% CFAR门限
EbN0 = 10.^(ebn0./10);
standardnlosstx=Stx(1,:);
%standardnlosstx=Stx1;% stx1 or stx ??
standardnlosstxe=sum(standardnlosstx.^2)/fs;
n00= standardnlosstxe/num/EbN0*band_sub;
deltaCFAR = sqrt(sum(pulse.^2)*(n00/2));
noise_thred = deltaCFAR*qfuncinv(1e-5);
