function [PPMseq,THseq] = PPM(seq,fc,Tc,Tf,delta,THcode,L)
dt=1./fc;
framesample=round(Tf./dt);
chipsample=round(Tc./dt);
PPMsample = round(delta./dt);
THp= length(THcode);
alllength = framesample*length(seq);
PPMseq=zeros(1,alllength);
THseq=zeros(1,alllength);
for k=1:length(seq)
    index=1+(k-1)*framesample;
    kTH = THcode(1+mod(k-1,THp));
    index = index +kTH*chipsample;
    THseq(1,index)= 1;
    index = index + PPMsample*seq(k);
    PPMseq(1,index)= 1;
end
% for zhentouchangdu=1:L
% index2=1+(zhentouchangdu-1)*framesample;
% kTH = THcode(1+mod(zhentouchangdu-1,THp));
% index2 = index2 +kTH*chipsample;
% THseq(1,index2)= 1;
% index2=index2 + PPMsample*seq(zhentouchangdu);
% PPMseq(1,index2)=1;
% end
end

